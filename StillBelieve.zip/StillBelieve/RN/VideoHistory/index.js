/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableHighlight,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
  ScrollView,
  ListView,
  Linking,
  AsyncStorage,
  Platform,
  PermissionsAndroid
} from 'react-native';
import styles from './styles'
import * as CONSTS from '@helper/consts'
import { StackNavigator } from 'react-navigation';
import { NavigationActions } from 'react-navigation'
const FBSDK = require('react-native-fbsdk');
import SQLiteManager from '@helper/SQLiteManager'
const SQLiteManagerObject = new SQLiteManager()
var _this;
import Loader from '@helper/Loader'

import Orientation from 'react-native-orientation';
import * as IMG from '@helper/ImgConst'
var { height, width } = Dimensions.get('window');
import ApiUtils from '@helper/ApiUtils'
import Header from '@Header'
import Validators from '@helper/Validators'
import * as CLR from '@helper/colors'
var Spinner = require('react-native-spinkit');
import * as Progress from 'react-native-progress';
import { showLoader, hideLoader, setWidthHeight } from '@store/modules/common/actions'
import { connect } from 'react-redux'
var ds;
var iOSDirectoryDS;

import Share, { ShareSheet, Button } from 'react-native-share';
import RNFetchBlob from 'react-native-fetch-blob'
let dirs = RNFetchBlob.fs.dirs
//var RNInstagramShare = require('react-native-instagram-share');
class VideoHistory extends Component {
  constructor(props) {
    super(props);
    ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
    iOSDirectoryDS = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });

    _this = this
    _this.state = {
      dataSource: ds.cloneWithRows([]),
      emailStr: '',
      passwordStr: '',
      confirmPasswordStr: '',
      isLoading: true,
      visible: false,
      progress: [],
      videos:[],
      videoDownloadPer:0,
      isVideoDownloaded:false,
      downloadedVideoURL:'',
      isiOSPathAvailable:false,
      iOSVideoDirectoryArray:[],
      iOSLocalDirectoryPath:'',
      buttonWidth:0,
      buttonHeight:0
    }

    console.ignoredYellowBox = ['Warning: ReactNative.createElement'];
    height = Dimensions.get('window').height;
    width = Dimensions.get('window').width;
  }


  render() {

    return (
      <View style={styles.container}>
        {_this.renderHeader()}
        <View style={{ backgroundColor: '#fff', flex: 1 }}>

          { (this.state.videos.length==0 && !this.state.isLoading)?
          <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
            <Text style={styles.errorText}>Oops! you have not rendered any videos yet</Text>
            </View>:this.renderHistoryList()}
        </View>

        {this.state.isiOSPathAvailable?<View style={{position:'absolute', left:0, top:0, right:0, bottom:0}}>
        <Text style={{height:40, backgroundColor:'#0c71b', textAlign:'center', width:width, paddingTop:10, marginTop:20, color:'white', fontWeight:'bold'}}>CHOOSE ALBUM TO SAVE VIDEO</Text>
        <View style={{position:'absolute', left:10, top:25}}>
          <TouchableOpacity style={{flexDirection:'row',alignItems:'center'}} onPress={()=>{
            this.setState({isiOSPathAvailable:false})
            }}>
                <Image source={IMG.BACK}/>
            </TouchableOpacity>
        </View>
        {_this.renderiOSDirectories()}
        </View>:<View/>}
        {this.state.isLoading?<Loader/>:null}
      </View>
    );
  }

  renderHeader() {
    return (<Header title={'Orders'} backButton={true} leftTitle={'Pick List'} leftCallback={() => _this.onPressGoBack()} rightTitle={_this.state.currentView == 'list' ? 'Card View' : 'List View'} rightCallback={() => _this.changeCurrentView()} navigator={_this.props.navigation} />)
  }

  renderHistoryList() {
    return (<View style={styles.listMainContainer}>
      <ListView
        style={styles.listInnerContainer}
        dataSource={ds.cloneWithRows(this.state.videos)}
        renderRow={(rowData) => _this.renderItem(rowData)}
        showsVerticalScrollIndicator={false}
         />
    </View>);
  }

  renderiOSDirectories() {
    return (<View style={[styles.listMainContainer]}>
      <ListView
        style={styles.listInnerContainer}
        dataSource={iOSDirectoryDS.cloneWithRows(this.state.iOSVideoDirectoryArray)}
        renderRow={(rowData) => {
          return <TouchableOpacity onPress={()=>{
            _this.setState({isiOSPathAvailable:false, isVideoDownloaded:true})
            var splitComp = _this.state.downloadedVideoURL.split("/");
              RNFetchBlob
                .config({
                    path : _this.state.iOSLocalDirectoryPath + '/'+splitComp[splitComp.length - 1]
                }).fetch('GET', _this.state.downloadedVideoURL)
                .progress((received, total) => {
                  _this.setState({videoDownloadPer:received/total})
                }).then((res) =>{
                  _this.setState({isVideoDownloaded:false})
                  _this.showAlert('Success', "Video downloaded successfully")
                  RNFetchBlob.fs.writeFile(rowData, res.path(), 'uri')
                      .then(()=>{
                      })
                })
                .catch((err) => {
                    _this.setState({isVideoDownloaded:false})
                    _this.showAlert('Alert', "Video Could not be downloaded! Please try again.")
                })
          }}>
          <View style={{justifyContent:'center', height:40, width:width}}>
            <Text style={{marginLeft:10}}>{rowData}</Text>
          </View>
          <View style={{backgroundColor:'#d3d3d3', height:1, width:width}}/>
          </TouchableOpacity>
        }}
        showsVerticalScrollIndicator={false}
         />
    </View>);
  }

  downloadVideoCallBack(videoURL) {
    var splitComp = videoURL.split("/");

    if (Platform.OS == 'ios') {
      RNFetchBlob.fs.checkPhotoPermission().then((isPermissionApproved) =>{
        if(isPermissionApproved){
            RNFetchBlob.fs.directoryChooser().then((albumAssets)=>{
          _this.setState({isiOSPathAvailable:true, downloadedVideoURL:videoURL, iOSVideoDirectoryArray:albumAssets[0], iOSLocalDirectoryPath:albumAssets[1]})
          }).catch((err) => {})
        }
      }).catch((err) => {
          _this.setState({isVideoDownloaded:false, downloadedVideoURL:''})
          _this.showAlert('Alert', "Directory not found! Please try again.")
      })

    } else {

      RNFetchBlob.fs.directoryChooser().then((path)=>{
      _this.setState({isVideoDownloaded:true, downloadedVideoURL:videoURL})
        RNFetchBlob
          .config({
              path : path + '/'+splitComp[splitComp.length - 1]
          }).fetch('GET', videoURL)
          .progress((received, total) => {
            _this.setState({videoDownloadPer:received/total})
          }).then((res) =>{
            _this.setState({isVideoDownloaded:false})
            _this.showAlert('Success', "Video downloaded successfully")
          })
          .catch((err) => {
              _this.setState({isVideoDownloaded:false})
              _this.showAlert('Alert', "Video Could not be downloaded! Please try again.")
          })

      }).catch((err) => {
          _this.setState({isVideoDownloaded:false})
          _this.showAlert('Alert', "Directory not found! Please try again.")
      })
    }
  }

  showAlert(title, message){
    Alert.alert(title,
      message,
      [
        {text: 'Ok', onPress: () => {}}
      ],
      { cancelable: true }
      )
  }

  renderItem(rowData) {



    var videoUrl = rowData.videoUrl
    let shareOptions = {
      title: "Still Believe",
      message: "Still Believe Video : ",
      url: videoUrl,
      subject: "Still Believe" //  for email
    };
    var imageURL = rowData.localImageUrl != null ? rowData.localImageUrl : rowData.imageUrl;

    var isRequestServed = rowData.isRequestServed;
    return (
      <View>
        <TouchableOpacity onPress={()=> this.props.navigation.navigate("ImageView", { imageURL: imageURL })} style={[styles.itemContainer, { height: 250, justifyContent: 'center' }]}>
          <Image
            style={{
              flex: 1,
              width: null,
              height: null,
              resizeMode: 'cover',
            }}
            source={{ uri: rowData.localImageUrl != null ? rowData.localImageUrl : rowData.imageUrl }}
          >


            <View style={{ position: 'absolute', backgroundColor: 'transparent' }}>

              <Image
                style={{
                  flex: 1,
                  width: width,
                  resizeMode: 'cover',
                  backgroundColor: 'transparent',
                  alignSelf: 'stretch',
                  justifyContent: 'center',
                  alignItems: 'center'

                }}
                source={IMG.SHADOW_TOP}
              />
              <View style={{ position: 'absolute', padding: 10, flexDirection: 'row', alignItems: 'center' }}>
                <Image source={this.getCompositionImage(rowData.composition)} />
                {/*<Text style={styles.videoTime}>{rowData.composition}</Text>*/}
                <View style={{ flex: 1 }} />
                <Text style={styles.videoTime}>{ApiUtils.getFormatedDate(rowData.createdAt)}</Text>
              </View>

            </View>


            <Image
              style={{
                flex: 1,
                width: width,
                resizeMode: 'cover',
                backgroundColor: 'transparent',
                alignSelf: 'stretch',
                position: 'absolute',
                bottom: 0,
              }}
              source={IMG.SHADOW_BOTTOM}
            />
             {this.renderSantaLoading(isRequestServed,rowData.status)}

          </Image>
          {isRequestServed ? <TouchableOpacity onPress={() => this.props.navigation.navigate("VideoPlayer", { imageURL: rowData.videoUrl })} style={{ position: 'absolute', alignSelf: 'center' }}><Image source={IMG.PLAY_VIDEO} /></TouchableOpacity> : null}
        </TouchableOpacity>
        <View style={{ flexDirection: 'row', marginHorizontal: 10 }}>
          <TouchableOpacity onPress={() => this.retake(rowData)} disabled={!isRequestServed} style={styles.actionButtonContainer}>
            <Image source={isRequestServed ? IMG.RETAKE_BTN : IMG.RETAKE_BTN_DISABLE} />
            <Text style={[styles.actionButtonText, { color: rowData.isRequestServed ? 'white' : '#a5b9d0' }]}>Retake</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => this.props.navigation.navigate('NewFeedback', { CameFrom: 'VideoHistory', VideoData: rowData })} disabled={!isRequestServed} style={[styles.actionButtonContainer, { marginHorizontal: 2 }]}>
            <Image source={isRequestServed ? IMG.FEEDBACK_BTN : IMG.FEEDBACK_BTN_DISABLE} />
            <Text style={[styles.actionButtonText, { color: rowData.isRequestServed ? 'white' : '#a5b9d0' }]}>Feedback</Text>
          </TouchableOpacity>
          <TouchableOpacity disabled={!isRequestServed} onPress={() => { this.shareCalled(shareOptions) }}  style={[styles.actionButtonContainer, { marginRight: 2 }]}>
            <Image source={isRequestServed ? IMG.SHARE_BTN  : IMG.SHARE_BTN_DISABLE} />
            <Text style={[styles.actionButtonText, { color: rowData.isRequestServed ? 'white' : '#a5b9d0' }]}>Share</Text>
          </TouchableOpacity>
          <TouchableOpacity onLayout={(event) => {
            var { x, y, width, height } = event.nativeEvent.layout;

            this.setState({ buttonWidth: width, buttonHeight: height });
          }} disabled={!isRequestServed} style={styles.actionButtonContainer}
          onPress={()=>{this.downloadVideoCallBack(rowData.videoUrl)}}
          >
            <Image source={isRequestServed ? IMG.DOWNLOAD_BTN : IMG.DOWNLOAD_BTN_DISABLE} />
            <Text style={[styles.actionButtonText, { color: rowData.isRequestServed ? 'white' : '#a5b9d0' }]}>Download</Text>
            {(this.state.isVideoDownloaded && this.state.downloadedVideoURL==videoUrl)?
            <View
            style={[styles.actionButtonContainer, {position:'absolute', backgroundColor:'rgba(0,0,0,0.5)', width:this.state.buttonWidth,height:this.state.buttonHeight}]}
            >
                <Progress.Circle size={25} indeterminate={false} progress={this.state.videoDownloadPer}/>
            </View>:<View/>}
          </TouchableOpacity>
        </View>
      </View>
    )
  }



  shareCalled(shareOptions) {
    // console.log('shareCalled')
    // var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
    // trackerID.trackEvent('VideoShared', 'SharedCalled');
    // console.log('SHARE OPTIONS');
    // var video = '@assets/demo.gif?id=dc48a20507664909aaa9f5d75756a39f&ext=gif';
    // var caption = "Test Message";
    // RNInstagramShare.share(video, caption);
    Share.open(shareOptions)
  }
  getCompositionImage(composition) {
    var imageSource = IMG.TREE_LEFT_ICON_SELECTED
    if (composition == 'RENDER THIS ONE CHIMNEY ON RIGHT') {
      imageSource = IMG.TREE_LEFT_ICON_SELECTED
    } else if (composition == 'RENDER THIS ONE CHIMNEY ON LEFT') {
      imageSource = IMG.TREE_RIGHT_ICON_SELECTED
    } else if (composition == 'Santa LEFT') {
      imageSource = IMG.TREE_ONLY_RIGHT_SELECTED
    } else if (composition == 'Santa RIGHT') {
      imageSource = IMG.TREE_ONLY_LEFT_SELECTED
    }
    return imageSource;
  }

  getType(composition) {
    var type = -1;
    if (composition == 'RENDER THIS ONE CHIMNEY ON RIGHT') {
      type = 1
    } else if (composition == 'RENDER THIS ONE CHIMNEY ON LEFT') {
      type = 2
    } else if (composition == 'Santa LEFT') {
      type = 4
    } else if (composition == 'Santa RIGHT') {
      type = 5
    }
    return type;
  }

  moveToRetake(rowData) {
    console.log('moveToRetake', rowData)
    Alert.alert('',
      'You may retake your image only once for this option.  Click Ok to proceed.',
      [
        {
          text: 'Ok', onPress: () => {
            var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
            trackerID.trackEvent('RetakeHappened', rowData.videoUrl);
            this.props.navigation.navigate("GamePlay", { type: this.getType(rowData.composition), authorization: authorization, rowData: rowData });
          }
        },
        { text: 'Cancel', onPress: () => console.log('Cancel Pressed'), style: 'cancel' },
      ],
      { cancelable: false }
    )

  }

  retake(rowData) {
    if (!rowData.isRetake && rowData.requestType == 'original') {
       if (Platform.OS === 'android') {
      PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.CAMERA).then(res => {
        console.log(res);
      })
      PermissionsAndroid.requestMultiple([PermissionsAndroid.PERMISSIONS.CAMERA, PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE])
        .then(res => {
          var grant = true;
          var keyName = '';
          for (var key in res) {
            keyName = key;
            var value = res[key];
            if (value != 'granted') {
              grant = false;
              break;
            }
          }
          if (!grant) {
            Alert.alert('Oops!', 'We need permissions to access your ' + keyName)
          } else {
            this.moveToRetake(rowData);
          }
        });
    } else {
      this.moveToRetake(rowData);
    }

    }else{
      Alert.alert('','You have exceeded your retake attempts.');
    }
  }

  renderSantaLoading(isRequestServed, status) {
    // status = 'inprocess'
    var progress = 0.1
    var imageSource = IMG.SANTA10;
    var imagePosition = 'flex-start'
    if (status == 'queued') {
      imageSource = IMG.SANTA10;
      imagePosition = 'flex-start'
    } else if (status == 'inprocess') {
      imageSource = IMG.SANTA50;
      imagePosition = 'center'
      progress = 0.5
    }

    if (isRequestServed) {
      return null
    } else {
      return (
        <View style={{
          position: 'absolute', padding: 10,
          bottom: 5, alignSelf: 'stretch', alignItems: 'center', justifyContent: 'center'
        }}>
          <Progress.Bar progress={progress} width={width - 40} color={'red'} borderWidth={2} borderColor={'white'} unfilledColor={'white'} />
          <Image style={{ marginTop: -55, alignSelf: imagePosition }} source={require('@assets/animation.gif')}>
            <Image style={{ alignSelf: 'center' }} source={imageSource} />
          </Image>
        </View>
      )
    }
  }


  timeSince(date) {
    date = new Date(date);
    var convertedDate = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
    return convertedDate;
  }


  renderItem1(rowData) {
    return (
      <TouchableOpacity onPress={() => _this.openBrowser(rowData.videoUrl)} style={styles.itemContainer}>
        <Image
          style={{ width: 66, height: 58 }}
          source={{ uri: rowData.imageUrl }}
        />
        <Text>{rowData.composition}</Text>
        <Text>{rowData.imageUrl}</Text>
      </TouchableOpacity>
    )
  }




  changeCurrentView(list) {


  }

  componentWillMount() {
    Orientation.lockToPortrait();
    const initial = Orientation.getInitialOrientation();
    if (initial === 'PORTRAIT') {
      // do something
    } else {
      // do something else
    }

    console.log('componentWillMount of VideoHistory Screen');
  }

  componentWillReceiveProps(nextProps){
      if (nextProps.notificationData.referalId) {
        console.log('nextProps.notificationData.referalId===', nextProps.notificationData.referalId);
      }
  }

  componentDidMount() {
    var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
    trackerID.trackScreenView('VIDEO_HISTORY');
    
    setTimeout(()=> {
      _this.getHistory();
    }, 100);

    Orientation.lockToPortrait();
    Orientation.addOrientationListener(_this._orientationDidChange);
  }

  _orientationDidChange = (orientation) => {
    if (orientation === 'LANDSCAPE') {
    } else {
    }
  }

  componentWillUnmount() {
    Orientation.getOrientation((err, orientation) => {
      console.log(`Current Device Orientation: ${orientation}`);
    });
    Orientation.removeOrientationListener(_this._orientationDidChange);

  }


  async getHistory() {
    _this.startLoading();
    await AsyncStorage.getItem('user', (err, result) => {
          authorization = JSON.parse(result).authorization;
          console.log('2',authorization);
            {

      url = 'video/history';

     var token = authorization;
      ApiUtils.get(url,token).then(([response, data]) => {

        console.log('@@@@@@ VIDEO HISTORY ', response)
        if (response.status === 200 || response.status === 201) {
          if(data.videos.length==0){
          //  Alert.alert('','Oops! You have not yet rendered any video yet');
             _this.stopLoading();
          }else{
            SQLiteManagerObject.insertVideos(data.videos,this.updateList,0);

         //   SQLiteManagerObject.getVideos()
         //   this.updateList(SQLiteManagerObject.getVideos())
      //     _this.updateList(data.videos);
          }
        }
        }).catch((error) => { _this.stopLoading(); console.log('ERROR : ', error.message); Alert.alert(error.message) })
      }
    })
  }
  updateList(list) {

    _this.setState({
      videos: list, dataSource: ds.cloneWithRows(list)
    },()=>  _this.stopLoading());
  }

  startLoading() {
  //  this.props.showLoader()
    this.setState({isLoading:true});
  }

  stopLoading() {
  //  this.props.hideLoader()
    this.setState({isLoading:false});
  }
  openBrowser(url) {
    if (url !== undefined && url !== null) {
      Linking.openURL(url);
    } else {
      Alert.alert('', 'Generating video, will be available soon');
    }
  }
}
const mapStateToProps = (state) => {
  return {
    loggedIn: state.auth.loggedIn,
    isLoading: state.common.isLoading,
    notificationData:state.notification.notificationData
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    showLoader: () => {
      dispatch(showLoader())
    }, hideLoader: () => {
      dispatch(hideLoader())
    }, setWidthHeight: (width, height) => {
      dispatch(setWidthHeight(width, height))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(VideoHistory)
