import {
  StyleSheet,
  Dimensions
} from 'react-native';
import { getCorrectFontSizeForScreen } from '@helper/multiResolution'
import * as CLR from '@helper/colors'
var { height, width } = Dimensions.get('window');
import commonStyles from '@helper/commonStyles'
import * as CONSTS from '@helper/consts'

const styles = StyleSheet.create({
container: {
    flex: 1,
  },
  innerContainer:{
    flex: 1,
    alignItems:'center'
  },
   santaText:{
    color: '#FFF',
    fontSize: getCorrectFontSizeForScreen(12),
   fontFamily: CONSTS.REGULAR_FONT,
  }, imageStyle:{
    padding : 5,
    height : 120,
    width : 120,
    borderRadius : 60,
    borderColor : 'white',
    borderWidth : 2,
    backgroundColor:'red'
  },imageBG:{height: 70, backgroundColor: CLR.APP_BLUE ,width:width}
  ,bgcolor:{backgroundColor: 'green'}
});

const finalStyle = {...styles,...commonStyles}
export default finalStyle;
