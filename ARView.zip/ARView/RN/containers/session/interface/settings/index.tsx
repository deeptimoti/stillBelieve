import * as React from 'react'
import { connect } from 'react-redux';
import { NavigationScreenProp } from 'react-navigation';
import { Switch, StyleSheet } from 'react-native'
import { Container, Button, Thumbnail, Content, List, ListItem, Text, Left, Right } from 'native-base';

import DisconnectModal from '../../../../components/modals/disconnect';

import { toggleMute } from '../../../../store/session/actions';

import { SettingsState } from '../../../../store/session/types';
import { Store } from '../../../../store';

interface Props extends SettingsState {
  navigation: NavigationScreenProp<any>,
  toggleMute(bool: boolean): void,
}

type State = {
  disconnectModal: boolean,
}

class Settings extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);

    this.state = {
      disconnectModal: false,
    }
  }

  render() {
    const { muted, toggleMute } = this.props;

    const Modals = () => {
      const { disconnectModal } = this.state;

      return <DisconnectModal isVisible={disconnectModal} callback={this.disconnect} close={this.toggleDisconnectModal} />
    }

    return (
      <Container>
        <Content>
          <List>
          <ListItem itemDivider>
              <Text>Audio</Text>
            </ListItem>
            <ListItem>
              <Left>
                <Text>Mute: {muted ? 'ON' : 'OFF'}</Text>
              </Left>
              <Right>
                <Switch
                  value={muted}
                  onValueChange={() => toggleMute(!muted)}
                  thumbColor='#7C91EC'
                  trackColor={{
                    false: '#C3C3C3',
                    true: '#C3C3C3'
                  }}
                />
              </Right>
            </ListItem>
            <ListItem itemDivider>
                  <Text>Drawing</Text>
            </ListItem>
            <ListItem>
              <Left>
                <Text>Color:</Text>
              </Left>
            </ListItem>
            <ListItem>
              <Left>
                <Text>Stroke:</Text>
              </Left>
            </ListItem>
            <ListItem itemDivider>
                  <Text>Objects</Text>
            </ListItem>
          </List>
          <Button onPress={this.toggleDisconnectModal} style={styles.disconnect} >
            <Text style={{ fontSize: 16 }}>Disconnect</Text>
          </Button>
        </Content>
        <Modals />
      </Container>
    )
  }

  toggleDisconnectModal = () => {
    this.props.navigation.closeDrawer();
    this.setState({ disconnectModal: !this.state.disconnectModal });
  }

  disconnect = () => {
    this.props.navigation.navigate('Sessions');
  }
}

const mapStateToProps = (state: Store) => ({
  ...state.session.settings,
})

const mapDispatchToProps = {
  toggleMute
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Settings)

const styles = StyleSheet.create({
  disconnect: {
    bottom: 0,
    marginVertical: 10,
    backgroundColor: '#7C91EC', 
    alignSelf: 'center',
  }
})