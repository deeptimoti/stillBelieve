import * as React from 'react'
import { connect } from 'react-redux';
import { StatusBar, StyleSheet, YellowBox, DeviceEventEmitter, TouchableWithoutFeedback } from 'react-native';
import { Container } from 'native-base';
import { withNavigation, NavigationScreenProp } from 'react-navigation';
import { AndroidBackHandler } from 'react-navigation-backhandler';
import Orientation from 'react-native-orientation'

import Viewport from './viewport';
import Interface from './interface';
import { chatConnect } from '../../store/chat/actions'

import { Store } from '../../store';
import { Participant } from '../../store/session/types';
import TwilioChat from '../../twilio/chat';
import { CurrentUserState } from '../../store/users/types';

type Props = {
  navigation: NavigationScreenProp<any>,
  error: any,
  twilioId: string
  twilioToken: string,
  currentUser: CurrentUserState,
  chatConnect(twilioToken: string, twilioId: string, identity: string): void,
  twilioChat: TwilioChat,
  participants: Participant[],
  isChatOpen: boolean
}

class Scene extends React.Component<Props> {
  constructor(props: Props) {
    super(props);
    
    YellowBox.ignoreWarnings(['Setting a timer']);
  }

  componentDidMount() {
    StatusBar.setHidden(true, 'none');
    Orientation.lockToLandscape();

    this.initializeSession();
  }

  componentWillUnmount() {
    Orientation.unlockAllOrientations();

    const { twilioChat } = this.props;
    if (twilioChat) {
      twilioChat.leaveCurrentChannel();
    }
  }

  render() {
    const { isChatOpen } = this.props;

    return (
      <Container>
        <Interface isChatOpen={isChatOpen}>
          <Viewport />
        </Interface>
        <AndroidBackHandler onBackPress={() => this.onBackButtonPressAndroid()} />
      </Container>
    )
  }

  initializeSession() {
    const { twilioToken, twilioId, chatConnect, currentUser } = this.props
    chatConnect(twilioToken, twilioId, currentUser._id);

    //Initialize Video here...
    DeviceEventEmitter.addListener('onSessionDisconnect', () => {this.onSessionDisconnect()});
  }

  onBackButtonPressAndroid() {
    //Close session and return to landing.
    this.props.navigation.navigate('Sessions');
    return true;
  }

  onSessionDisconnect() {
    this.props.navigation.navigate('Sessions');
  };
}

const mapStateToProps = (state: Store) => ({
  error: state.twilio.error,
  twilioId: state.twilio.id,
  twilioToken: state.twilio.token,
  currentUser: state.users.current,
  participants: state.session.participants,
  isChatOpen: state.chat.isOpen,
  twilioChat: state.chat.twilioChat,
})

const mapDispatchToProps = {
  chatConnect,
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withNavigation(Scene));
