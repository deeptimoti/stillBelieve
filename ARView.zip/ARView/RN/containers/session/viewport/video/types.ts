export type Cords = {
    x: number,
    y: number
}