import {
  StyleSheet,
  Dimensions
} from 'react-native';
import { getCorrectFontSizeForScreen } from '@helper/multiResolution'
import * as CLR from '@helper/colors'
var { height, width } = Dimensions.get('window');
import commonStyles from '@helper/commonStyles'
import * as CONSTS from '@helper/consts'

const styles = StyleSheet.create({
    container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center'
  },titleText:{
    fontSize:getCorrectFontSizeForScreen(10),
    fontFamily: CONSTS.REGULAR_FONT,
    color:CLR.FORGOT_COLOR,
    textAlign:'center',
    marginLeft:30,
    marginRight:30,
    marginTop:20
  },
  messageText:{
     marginBottom:0,
     textAlign: 'center',
     fontFamily:CONSTS.REGULAR_FONT,
     fontSize:getCorrectFontSizeForScreen(12),
     color:CLR.INPUT_TEXT_PROFILE
  },
  popupContainer:
  { 
    backgroundColor: 'white', 
    borderRadius: 30, 
    alignItems: 'center',
    margin:40 ,
  },
  popupTopContainer:{ 
    padding:10,
    backgroundColor: CLR.APP_GRAY, 
    borderTopLeftRadius: 30,  
    borderTopRightRadius: 30,
    alignItems: 'center'
  },
  okCancel:{
     alignItems: 'center',
     alignSelf: 'stretch', 
     backgroundColor: CLR.APP_BLUE, 
     padding: 10,
     borderRadius: 20 }
});
const finalStyle = {...styles,...commonStyles}
export default finalStyle;
