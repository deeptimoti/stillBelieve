/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Text,
  View,
  Dimensions,
  TouchableHighlight,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
  ScrollView,
  AsyncStorage,
  Platform,
  KeyboardAvoidingView,
  Keyboard
} from 'react-native';
import styles from './styles'
import * as CONSTS from '@helper/consts'
import { StackNavigator } from 'react-navigation';
import { NavigationActions } from 'react-navigation'
import Orientation from 'react-native-orientation';
import * as IMG from '@helper/ImgConst'

import ApiUtils from '@helper/ApiUtils'
import Validators from '@helper/Validators'
import * as CLR from '@helper/colors'
var _this;
import { showLoader, hideLoader, setWidthHeight, showRedeem, hideRedeem } from '@store/modules/common/actions'
import { connect } from 'react-redux'
import Header from '@Header'
import Modal from 'react-native-modal'

class RedeemGift extends Component {
  constructor(props) {
    super(props);
    console.log(this.props.navigation);
    _this = this;
    this.state = {
      referCode: '',
      popupTop:-100
    }
    console.ignoredYellowBox = ['Warning: ReactNative.createElement'];
  }

  render() {
    var { height, width } = Dimensions.get('window');
    return (this.props.isRedeem ?
      <TouchableOpacity activeOpacity={10} onPress={()=>{console.log("keyboard dismiss");Keyboard.dismiss()} } style={{ position: 'absolute', width: width, height: height, backgroundColor: '#00000080', alignItems: 'center', justifyContent: 'center' }}>
        {this.renderRedeemPopup()}
      </TouchableOpacity> : null
    );
  }

  renderRedeemPopup() {
    return (<View style={[styles.popupContainer,{marginTop:this.state.popupTop}]}>
      <View style={styles.popupTopContainer}>
      <Text style={[styles.messageText,{paddingHorizontal:20}]}>Please enter referral code{'\n'}to bring the magic of{'\n'}Still Believe into your house!
</Text>
      </View>
      <TextInput
            autoCapitalize="none"
            returnKeyType={"go"}
            onSubmitEditing={(event) => {
                this.submit();
            }}
            underlineColorAndroid='transparent'
            value={this.state.referCode}
            style={[styles.inputBox, {alignSelf:'stretch',margin:10,marginLeft:5,marginRight:5}]}
            placeholder={'Referral Code'}
            onChangeText={(text) => this.setState({ referCode: text })} />

      <View style={{alignSelf: 'stretch', height: 1, backgroundColor: 'black', marginTop: 10}} />
      <View style={{paddingVertical:15,flexDirection:'row', alignSelf: 'stretch',alignItems:'center',justifyContent:'center'}} >
      <TouchableOpacity onPress={() => this.props.hideRedeem()} style={[styles.okCancel,{backgroundColor:CLR.APP_GRAY}]}>
        <Text style={styles.messageText}>CANCEL</Text>
      </TouchableOpacity>
      <View style={{margin:10}}/>
      <TouchableOpacity  onPress={() => this.submit()} style={styles.okCancel}>
        <Text style={[styles.messageText,{color:'white'}]}>SUBMIT</Text>
      </TouchableOpacity>
      </View>
    </View>)
  }


  renderHeader() {
    return (<Header title={'Send Gift'} backButton={true} leftCallback={() => this.onPressGoBack()} rightTitle={this.state.currentView == 'list' ? 'Card View' : 'List View'} rightCallback={() => this.changeCurrentView()} navigator={this.props.navigation} />)
  }

  renderSubmitButton() {
    return (
      <TouchableOpacity onPress={() => this.submit()} style={styles.buttonContainer}>
        <Text style={styles.buttonText}>SUBMIT</Text>
      </TouchableOpacity>
    )
  }

  isValidate() {
    if (this.state.referCode == '') {
      Alert.alert('', 'Please enter referral code');
      return false;
    }
    return true;
  }

  submit() {
    if (this.isValidate()) {
      this.startLoading();
      url = 'refer/verifyReferCode';
      body = {
        "referCode": this.state.referCode.trim(),
      }
      token = this.props.userDetails.authorization;
      ApiUtils.post(url, body, token).then(([response, data]) => {
        this.stopLoading();
        console.log(data);
        if (response.status === 200 || response.status === 201) {
        //  Alert.alert('', data.message);
            _this.props.hideRedeem();
           _this.props.navigator.navigate('GiftSelection', {type:'redeem',email:this.state.emailStr,giftBy:data})
        } else {
          Alert.alert('', data.message);
        }
      }).catch((error) => {
        this.stopLoading();
        console.log('ERROR : ', error);
        Alert.alert(error.message)
      })
    }
  }
  startLoading() {
    this.props.showLoader()
  }
  stopLoading() {
    this.props.hideLoader()
  }

  componentWillMount () {
    this.keyboardDidShowListener = Keyboard.addListener('keyboardDidShow', this._keyboardDidShow);
    this.keyboardDidHideListener = Keyboard.addListener('keyboardDidHide', this._keyboardDidHide);
  }

  componentWillUnmount () {
    this.keyboardDidShowListener.remove();
    this.keyboardDidHideListener.remove();
  }

  _keyboardDidShow () {
    //alert('Keyboard Shown');
    _this.setState({popupTop:-100})
  }

  _keyboardDidHide () {
    //alert('Keyboard Hidden');
    _this.setState({popupTop:0})
  }
}

const mapStateToProps = (state) => {
  return {
    userDetails: state.auth.userDetails,
    isRedeem: state.common.isRedeem
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    showLoader: () => {
      dispatch(showLoader())
    }, hideLoader: () => {
      dispatch(hideLoader())
    }, setWidthHeight: (width, height) => {
      dispatch(setWidthHeight(width, height))
    }, showRedeem: () => {
      dispatch(showRedeem())
    }, hideRedeem: () => {
      dispatch(hideRedeem())
    }

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(RedeemGift)
