import * as React from 'react'
import { connect } from 'react-redux';
import { StyleSheet, TouchableWithoutFeedback, Alert } from 'react-native'
import { NativeModules, NativeEventEmitter } from 'react-native'
import { Container, Thumbnail, View } from 'native-base'

import { setCurrentTool } from '../../../../store/session/actions'
import { toggleChat } from '../../../../store/chat/actions'

import tools from './assets/tools'

import { Tool } from './types'
import { Store } from '../../../../store';
const myModuleEvt = new NativeEventEmitter(NativeModules.MyModule)

type Props = {
    currentTool: string,
    setCurrentTool(name: string): void,
    toggleChat(bool?: boolean): void,
    resetTool(): void
}

class Toolbar extends React.Component<Props> {

    componentDidMount(){
        myModuleEvt.addListener('reset_tool', () => this.resetTool());
    }

    componentWillMount(){
        myModuleEvt.removeListener('reset_tool', () => this.resetTool());
    }

    resetTool(){
        this.props.setCurrentTool('');
    }


    render() {
        console.log('tool: ', this.props.currentTool)
        const items = tools.map((tool) => {
            return (
                <TouchableWithoutFeedback
                    onPress={() => this.handlePress(tool)} 
                    key={tool.name}
                >
                    <Thumbnail source={this.props.currentTool === tool.name ? tool.icon_tap : tool.icon}/>
                </TouchableWithoutFeedback>
            )
        });

        return (
            <Container style={styles.container}>
                {items}
            </Container>
        )
    }

    handlePress = (tool: Tool) => {
        if (tool.name === 'chat') {
            this.props.toggleChat();
        } else {
            this.props.setCurrentTool(tool.name);
        }
    }
}

const styles = StyleSheet.create({
    container: {
        width: '100%',
        maxHeight: 60,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-evenly',
        backgroundColor: '#C3C3C3',
        paddingLeft: '15%',
        paddingRight: '15%',
    },
})

const mapStateToProps = (state: Store) => ({
  currentTool: state.session.toolbar.currentTool
})

const mapDispatchToProps = {
    toggleChat,
    setCurrentTool,
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Toolbar)