import {
  StyleSheet,
  Dimensions
} from 'react-native';

import {getCorrectFontSizeForScreen} from '@helper/multiResolution'
var {height, width} = Dimensions.get('window');
import * as CONSTS from '@helper/consts'
import * as CLR from '@helper/colors'
const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#000000'
  },
  preview: {
    flex: 1,
  },
  capture: {
    backgroundColor: '#fff',
    borderRadius: 5,
    color: '#00000080',
    padding: 10,
    margin: 40
  },
  overlayContainer1:{
    width:width,
    height:height,
    flex:1,
    flexDirection:'row',
    position:'absolute',
    backgroundColor:'#00000080',
    justifyContent:'space-around',
    bottom:0
  },
  overlayContainer:{
    width:width,
    height:height,
    flex:1,
    flexDirection:'row',
    position:'absolute',
    marginLeft:-20,
    bottom:0
  },
  overlayImage:{
    alignSelf:'flex-end',

  },
  overlayFireplace:{
    alignSelf:'flex-end',
    marginBottom:30
  },
  bottomMsg:{
    color:'#a5b9d0',
    textAlign:'center',
    padding:5,
    fontFamily:CONSTS.REGULAR_FONT
  },
  messageText:{
     margin:20,marginBottom:0, textAlign: 'center',fontFamily:CONSTS.REGULAR_FONT,fontSize:getCorrectFontSizeForScreen(14)
  },
  spinner: {
    marginBottom: 50
  },
  messageTextPop:{
     marginBottom:0,
     textAlign: 'center',
     fontFamily:CONSTS.REGULAR_FONT,
     fontSize:getCorrectFontSizeForScreen(12),
     color:CLR.INPUT_TEXT_PROFILE
  },
  okCancel:{
     alignItems: 'center',
    margin:10,
     backgroundColor: CLR.APP_BLUE, 
     width:100,
     padding: 10,
     borderRadius: 20 }
}
 );
export default styles;
