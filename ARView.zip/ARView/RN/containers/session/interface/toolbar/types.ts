export type Tool = {
    name: string,
    icon: any,
    icon_tap: any,
    toggle?: boolean,
}