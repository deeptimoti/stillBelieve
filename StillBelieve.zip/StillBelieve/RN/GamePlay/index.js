/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import SQLiteManager from '@helper/SQLiteManager'
const SQLiteManagerObject = new SQLiteManager()
import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableHighlight,
  Image,
  TouchableOpacity,
  Alert,
  Platform,
  AsyncStorage,
  BackHandler
} from 'react-native';

import Permissions from 'react-native-permissions'

var width = Dimensions.get('window').height;
var height = Dimensions.get('window').width;
import Camera from 'react-native-camera';
import { captureRef } from "react-native-view-shot";
import * as CONSTS from '@helper/consts'
import { StackNavigator } from 'react-navigation';
import styles from './styles'
import ApiUtils from '@helper/ApiUtils'
import Device from '@helper/DetectDeviceService'

import ImageResizer from 'react-native-image-resizer';
var InAppUtils = require('NativeModules').InAppUtils;
const InAppBilling = require("react-native-billing");
import { NavigationActions } from 'react-navigation'
import Modal from 'react-native-modal'
import Loader from '@helper/Loader'
import * as IMG from '@helper/ImgConst'

const TREE_RIGHT_ICON_SELECTED = require('@assets/tree_in_right_selected.png');
const TREE_LEFT_ICON_SELECTED = require('@assets/tree_in_left_selected.png');
const TREE_CENTER_ICON_SELECTED = require('@assets/tree_in_center_selected.png');
const TREE_ONLY_LEFT_SELECTED = require('@assets/only_tree_left.png');
const TREE_ONLY_RIGHT_SELECTED = require('@assets/only_tree_right.png');

const TREE_RIGHT_ICON = require('@assets/tree_in_right.png');
const TREE_LEFT_ICON = require('@assets/tree_in_left.png');
const TREE_CENTER_ICON = require('@assets/tree_in_center.png');
const TREE_ONLY_LEFT = require('@assets/only_tree_left_disable.png');
const TREE_ONLY_RIGHT = require('@assets/only_tree_right_disable.png');
import { PermissionsAndroid } from 'react-native';


import Orientation from 'react-native-orientation';
import { showLoader, hideLoader, setWidthHeight } from '@store/modules/common/actions'
import { connect } from 'react-redux'
import { RNS3 } from 'react-native-aws3';
var i = 0;
const file = {
  // `uri` can also be a file system path (i.e. file://)
  uri: "assets-library://asset/asset.PNG?id=655DBE66-8008-459C-9358-914E1FB532DD&ext=PNG",
  name: "image.png",
  type: "image/png"
}

const options = {
  keyPrefix: "staging/",
  bucket: "scot-user-images",
  region: "us-east-1",
  accessKey: "AKIAJMAH4VBKL7F77DGQ",
  secretKey: "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",
  successActionStatus: 201
}

// const options = {
//   keyPrefix: "staging/",
//   bucket: "scot-users-images",
//   region: "eu-west-2",
//   accessKey: "AKIAIBDZ2JUUEWY7G5BA",
//   secretKey: "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",
//   successActionStatus: 201
// }
var Spinner = require('react-native-spinkit');
var _this;
import Alert1 from '@helper/Alert'
export class GamePlay extends Component {

    drawAlert() {
    // setTimeout(() => {
    //   this.setState({text: "Will dismiss in 1 second"}, () => {
    //     setTimeout(() => {
    //    //   this.setState({visible: false})
    //     }, 1000);
    //   })
    // }, 4000); // fake API request
    return (
      <Alert1 text={this.state.text} visible={this.state.visible} cancelAlert={()=>this.cancelAlert()} okAlert={()=>this.okAlert()}/>
    )
  }
  okAlert(){
     this.setState({visible: false})
     RNS3.abort()
     this.stopLoading()
    _this.props.navigation.goBack()
  }
  cancelAlert(){
      _this.setState({visible: false})
      _this.props.showLoader();

  }

  constructor(props) {
    super(props);
    _this = this;
    const { type, rowData, giftBy } = this.props.navigation.state.params
    this.state = {
      imageURI: '',
      captured: false,
      type: type,
      fullPath: '',
      authorization: this.props.navigation.state.params.authorization,
      rowData: rowData,
      isModalVisible: false,
      data: {},
      giftBy: giftBy,
      body:{},
      isImageUploaded:false,
      hasOnboardingMediaShown:((typeof this.props.navigation.state.params.hasOnboardingMediaShown != 'undefined')?this.props.navigation.state.params.hasOnboardingMediaShown:true),
      hasOnboardingMediaShown_Retake:false,
      isShowRetakeMedia:false,
      visible: false,
      isIAPEnable:false,
      text: "Its taking longer than usual . Do you still want to continue or stop it?"
    }
    console.disableYellowBox = true;
    width = Dimensions.get('window').height;
    height = Dimensions.get('window').width;
    //  BackHandler.addEventListener('hardwareBackPress', function() {
    //   console.log('back press');
    //   _this.props.hideLoader();
    //   return true;
    // });
  }

  _showModal = () => this.setState({visible:false,isModalVisible: true })

  _hideModal = () => this.setState({ isModalVisible: false }, () => this.uploadSuccess())

  render() {
    return (
      <View style={{flex:1}}>
      <View
        ref="screen_view"
        style={styles.container} >
        {this.renderCamera()}
        {this.renderCapturedImage()}
        {this.renderOverlay()}
        {this.renderBackButton()}
        {this.renderRightActionBar()}
        {this.renderBottomMsg()}
        {this.renderLoader()}
        {this.renderImageProcessing()}
        {this.renderConfrimationPopup()}

        {this.state.visible?this.drawAlert():<View/>}
      </View>
      {!this.state.hasOnboardingMediaShown?<View style={{flex:1, position:'absolute', left:0, top:0}}>
        <Image style={{width:width, height:height, resizeMode:'stretch'}} source={ApiUtils.getPathForOnBoardingScreen_Camera(this.props.navigation.state.params.cameraIndex)} />
        <TouchableOpacity style={{flex:1, position:'absolute', right:60, bottom:20, width:100, height:60}} onPress={()=>{
          this.setState({hasOnboardingMediaShown:true})
          AsyncStorage.setItem(this.props.navigation.state.params.cameraStorageKey, 'OnBoardingMedia_Retake', () => {});
        }}>
        <Text style={{color:'white', fontSize:20, backgroundColor:'transparent', fontWeight:'bold'}}>Done</Text>
        </TouchableOpacity>
       </View>:<View/>}
       {this.state.isShowRetakeMedia?<View style={{flex:1, position:'absolute', left:0, top:0}}>
         <Image style={{width:width, height:height, resizeMode:'stretch'}} source={ApiUtils.getPathForOnBoardingScreen_Retake()} />
         <TouchableOpacity style={{flex:1, position:'absolute', right:60, bottom:20, width:100, height:60}} onPress={()=>{
           this.setState({isShowRetakeMedia:false})
           AsyncStorage.setItem('OnBoardingMedia_Retake', 'OnBoardingMedia_Retake', () => {});
         }}>
         <Text style={{color:'white', fontSize:20, backgroundColor:'transparent', fontWeight:'bold'}}>Done</Text>
         </TouchableOpacity>
        </View>:<View/>}

      </View>
    );
  }

  renderBackButton(){
   top =  Platform.OS == 'ios' ? 0 : 0
    return(
      <TouchableOpacity style={{position:'absolute',padding:20,top:top, left:-10}}
          onPress = {()=> _this.props.navigation.goBack()}>
      <Image source = {IMG.BACK}/>
      </TouchableOpacity>
    )
  }

  renderConfrimationPopup() {
    return (this.state.isModalVisible ? <View style={{ position: 'absolute', width: width, height: height, alignItems: 'center', justifyContent: 'center', backgroundColor: '#00000080' }}>
      <View style={{ backgroundColor: 'white', borderRadius: 25, alignItems: 'center' }}>
        <Text style={styles.messageText}>
          The magic has begun! We will notify{'\n'}you as soon as your memory is complete.{'\n'}You can view status under ‘Orders’{'\n'}in the drop down menu.
</Text>
        <Image
          source={require('@assets/thumb.png')}
        />
        <View style={{ alignSelf: 'stretch', height: 0.5, backgroundColor: 'gray', marginTop: 0 }} />
        <TouchableOpacity  onPress={() => this._hideModal()} style={styles.okCancel}>
        <Text style={[styles.messageTextPop,{color:'white'}]}>  OK  </Text>
      </TouchableOpacity>
      </View>
    </View> : null)
  }

  renderImageProcessing() {
    if (this.state.captured && this.state.imageURI === '') {
      return (
        <Loader/>
      );
    } else {
      return null
    }
  }

  renderLoader() {
    return (
      this.state.isLoading ? <View style={{ position: 'absolute', width: width, height: height, alignItems: 'center', justifyContent: 'center', backgroundColor: '#00000080' }}>
        <Spinner style={styles.spinner} isVisible={this.state.isLoading} size={100} type={'Circle'} color={'#0a5a99'} />
      </View> : null
    );
  }

  renderBottomMsg() {
    let msg = "Place your fireplace and tree within the guide frames. Then, take the picture!"
    if (this.state.type === 2) {
      msg = "Place your fireplace and tree within the guide frames. Then, take the picture!"
    } else if (this.state.type === 4 || this.state.type === 5) {
      msg = "Place your tree within the guide frames. Then, take the picture!"
    }
    return (
      !this.state.captured ?
        <View style={{ position: 'absolute', bottom: 0, alignItems: 'center', backgroundColor: '#0a5a99', width: width }}>
          <Text style={styles.bottomMsg}>{msg}</Text>
        </View> : null
    );
  }


  renderRightActionBar() {
    return (<View style={{ height: height, flex: 1, position: 'absolute', right: 0, backgroundColor: 'black', alignItems: 'center', justifyContent: 'center', width:68 }}>
      {!this.state.captured ?
        <View style={{ marginTop: 5, position: 'absolute', top: 0 }}>
          <TouchableOpacity onPress={() => this.change(1)}><Image style={{ margin: 5 }} source={this.state.type == 1 ? TREE_LEFT_ICON_SELECTED : TREE_LEFT_ICON} /></TouchableOpacity>
          <TouchableOpacity onPress={() => this.change(2)}><Image style={{ margin: 5 }} source={this.state.type == 2 ? TREE_RIGHT_ICON_SELECTED : TREE_RIGHT_ICON} /></TouchableOpacity>
          <TouchableOpacity onPress={() => this.change(4)}><Image style={{ margin: 5 }} source={this.state.type == 4 ? TREE_ONLY_RIGHT_SELECTED : TREE_ONLY_RIGHT} /></TouchableOpacity>
          <TouchableOpacity onPress={() => this.change(5)}><Image style={{ margin: 5 }} source={this.state.type == 5 ? TREE_ONLY_LEFT_SELECTED : TREE_ONLY_LEFT} /></TouchableOpacity>
        </View> : null}
      {!this.state.captured ?
        <TouchableOpacity onPress={() => {

          Permissions.check('camera').then(response => {

           // Response is one of: 'authorized', 'denied', 'restricted', or 'undetermined'
           if (response == 'denied' || response == 'undetermined') {
             Alert.alert('', 'Please enable camera permissions and proceed')
           } else {
             this.takePicture(true)
           }
         })

        }} style={{ padding: 5, marginTop: 100 }}>
          <Image
            resizeMode={'contain'}
            source={require('@assets/button.png')}
          />
        </TouchableOpacity> :
        <View style={{ backgroundColor: 'transparent', alignItems: 'center', justifyContent: 'flex-end' }}>
          <TouchableOpacity onPress={() => { this.uploadImage(); console.log('######', this.state.imageURI); console.log('@@@@@@@', this.state.fullPath) }} style={{ padding: 5 }}>
            <Image
              resizeMode={'contain'}
              source={require('@assets/done.png')}
            />
          </TouchableOpacity>
          <View style={{ height: 30 }} />
          <TouchableOpacity onPress={() => this.setCaptured(false)} style={{ padding: 5, justifyContent:'center' }}>
            <Image
              resizeMode={'contain'}
              source={require('@assets/retake.png')}
            />
            <Text style={{marginLeft:2, Top:8, color:'white', fontSize:11}}>Retake</Text>
          </TouchableOpacity>
        </View>}
    </View>);
  }

  async processAndroidPayment(body) {

  var products_id = ['com.stillbelieve.treeleftcenterfire', 'com.stillbelieve.treerightcenterfire', 'com.stillbelieve.treeright', 'com.stillbelieve.treeleft'];

  var purchase_product = products_id[this.state.type>3?(this.state.type - 2):(this.state.type - 1)];

    await InAppBilling.close();
    InAppBilling.open()
      .then(() => InAppBilling.purchase(purchase_product)
        .then((details) => {
          var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
          trackerID.trackEvent('Product_Purchase', purchase_product);
          InAppBilling.consumePurchase(purchase_product);
          _this.notifyCall(details, purchase_product);
          return InAppBilling.close();
        }, (error) => {
          _this.stopLoading()
          Alert.alert('',''+error.message);
          _this.props.navigation.goBack()
        }))
  }

  processiOSPayment(body) {
    var products_id = ['com.stillbelieve.treeLeftCenterfire', 'com.stillbelieve.treeRightCenterfire', 'com.stillbelieve.treeRight', 'com.stillbelieve.treeLeft'];
     InAppUtils.loadProducts(products_id, (error, products) => {

       if(error != null) {
         _this.stopLoading()
         Alert.alert('Error Load Products',''+error.message);
         _this.props.navigation.goBack()

       }

    InAppUtils.canMakePayments((canMakePayments) => {
      if (!canMakePayments) {
        _this.stopLoading()
        Alert.alert('Not Allowed', 'This device is not allowed to make purchases. Please check restrictions on device');
        _this.props.navigation.goBack()

      }
      else {
        var purchase_product = products_id[this.state.type>3?(this.state.type - 2):(this.state.type - 1)];
        InAppUtils.purchaseProduct(purchase_product, (error, response) => {
          if (typeof response != 'undefined') {
            var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
            trackerID.trackEvent('Product_Purchase', purchase_product);
            _this.notifyCall(response, purchase_product);

          }
          else {
            _this.stopLoading()
            Alert.alert('',''+error.message);
            _this.props.navigation.goBack()
          }
        });
      }
    })
  });
  }

  processPayment(body) {
    if (Platform.OS == 'ios') {
      this.processiOSPayment(this.state.type, body);
    }
    else {
      this.processAndroidPayment(body);
    }
  }
  uploadImage() {
    this.startLoading();
    this.setState({isImageUploaded:false})

    var file = {
      uri: this.state.imageURI,
      name: 'original' + new Date().getTime() + "image.jpg",
      type: "image/jpg"
    }
    ImageResizer.createResizedImage(this.state.imageURI, 1920, 1080, 'JPEG', Platform.OS=='android'?100:50).then((response) => {
      var file1 = {
        uri: response.uri,
        name: 'resized' + new Date().getTime() + "image.jpg",
        type: "image/jpg",
      }
      this.uploadOnS3(file1, 'resized image');
    }).catch((err) => {
      console.log('error in uploadOns3', err);
    });
  }

  uploadOnS3(file, imageType) {

    //*> Show popup to abort the connection
    setTimeout(()=> {
      if (!this.state.isImageUploaded) {
        _this.props.hideLoader()
        _this.setState({visible:true})
      }
    }, 20000);

    RNS3.put(file, options).then(response => {
      this.setState({isImageUploaded:true})
       if (response.status !== 201)
        throw new Error("Failed to upload image to S3");
      else {
        console.log('uploaded successfully on S3');
        _this.setState({visible:false})
        var location = response.body.postResponse.location
        this.uploadURLOnServer(location);
      }
    }).catch(err => {
      this.setState({isImageUploaded:true})
      this.stopLoading()
      Alert.alert('', 'Network Request Failed')
    });
  }


  change(type) {
    if (typeof this.state.rowData === 'undefined') {
      this.setState({ type: type });
    }
    else {

    }
  }

  renderCamera() {
    return (
      !this.state.captured ?
        <View style={{flex:1, width:width-68, left:0, right:68, bottom:0}}><Camera
          ref={(cam) => {
            this.camera = cam;
          }}
          captureMode={Camera.constants.CaptureMode.still}
          captureTarget={Camera.constants.CaptureTarget.disk}
          orientation={Camera.constants.Orientation.landscapeRight}
          style={[{width:width - 68, height:height}]}
          aspect={Camera.constants.Aspect.fill}
          captureQuality={Camera.constants.CaptureQuality["1080p"]}
        >
        </Camera></View> : null
    )
  }
  renderOverlay() {
    var tree = require('@assets/tree_left_camera.png')
    var fire = require('@assets/fire_place.png')
    if (this.state.captured) {
      tree = require('@assets/tree_left_active.png')
      fire = require('@assets/fire_place_active.png')
    }
    if (this.state.type === 1) {
      return (
        <View style={[styles.overlayContainer, { width: width - 68, height: height, right: 68}]}>
        <View style={{position:'absolute', left:0, bottom:0, top:0, flex:1}}>
          <Image
            resizeMode={'stretch'}
            source={tree}
            style={[styles.overlayImage, {height:height, marginLeft:15}]}
          />
          </View>
          <View style={{position:'absolute', left:0, right:0, top:Device.isiPhone5?50:100, bottom:0, justifyContent:'center', alignItems:'center'}}>
          <Image
            resizeMode={'contain'}
            source={fire}
          />
          </View>
        </View>
      );
    } else if (this.state.type === 2) {

      tree = require('@assets/tree_right_camera.png')
      if (this.state.captured) {
        tree = require('@assets/tree_right_active.png')
      }

      return (
        <View style={[styles.overlayContainer, { width: width - 68, height: height, right: 68}]}>
        <View style={{position:'absolute', right:0, bottom:0}}>
          <Image
            resizeMode={'stretch'}
            source={tree}
            style={[styles.overlayImage, {height:height, right:15}]}
          />
          </View>
          <View style={{position:'absolute', left:0, right:0, top:Device.isiPhone5?50:100, bottom:0, justifyContent:'center', alignItems:'center'}}>
          <Image
            resizeMode={'contain'}
            source={fire}
          />
          </View>
        </View>
      );
    } else if (this.state.type == 4) {
      tree = require('@assets/tree_right_r.png')
      if (this.state.captured) {
        tree = require('@assets/tree_right_green.png')
      }

      return (
        <View style={[styles.overlayContainer, { width: width - 68, height: height, right: 68}]}>
          <Image
            resizeMode={'stretch'}
            source={tree}
            style={[styles.overlayImage, { height:height, position: 'absolute', right:0 }]}
          />
        </View>
      );
    } else if (this.state.type == 5) {

      tree = require('@assets/tree_l.png')
      if (this.state.captured) {
        tree = require('@assets/tree_green_l.png')
      }

      return (
        <View style={[styles.overlayContainer, { width: width - 68, height: height, right: 68}]}>
          <Image
          resizeMode={'stretch'}
          source={tree}
          style={[styles.overlayImage, {height:height, marginLeft:0}]}
          />
        </View>
      );
    }

  }
  renderActionButtons() {
    return (
      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0, alignItems: 'center' }}>
        {!this.state.captured ?
          null
          :
          <View style={{ alignItems: 'center', flexDirection: 'row' }}>
            <TouchableOpacity onPress={() => this.setCaptured(false)}><Text style={styles.capture}>[CANCEL]</Text></TouchableOpacity>
            <TouchableOpacity onPress={() => this.setCaptured(false)}><Text style={styles.capture}>[UPLOAD]</Text></TouchableOpacity>
          </View>}
      </View>
    );
  }

  renderCapturedImage() {
  //  console.log('this.state.imageURI', this.state.imageURI, this.state.captured);
    if (this.state.captured && this.state.imageURI == '') {
      return null
    } else {
      return (
        this.state.captured ?
          <Image
            style={{ width: width - 68, height: height, position: 'absolute', left: 0 }}

            source={{ uri: this.state.imageURI }} /> :
          <View style={{ width: width - 200, height: height, position: 'absolute', backgroundColor: 'transparent' }} />
      );
    }

  }



  setCaptured(flag) {
    this.setState({ captured: flag }, () => flag ? this.setState({ imageURI: '' }) : console.log('hey'));

    if (flag && !this.state.hasOnboardingMediaShown_retake) {
      this.setState({isShowRetakeMedia:true})
    }

  }

  takePicture() {

   console.log('------takePicture');


    const options = {};
    this.camera.capture({ metadata: options })
      .then((data) => { console.log(data); this.setState({ imageURI: data.path }) })
      .catch(err => console.error(err));
    captureRef(this.refs['screen_view'], {
      format: "png",
      quality: 1
    })
      .then(
      uri => { this.setState({ fullPath: uri }, () => { Platform.OS === 'ios' ? console.log('ios') : this.setCaptured(true) }) },
      //uri => { this.setState({ fullPath: uri })},
      error => console.error("Oops, snapshot failed", error)
      ).catch(err => { console.error('err', err); this.setCaptured(true) });
    { Platform.OS === 'ios' ? this.setCaptured(true) : console.log('android') }
  }

  getSelectionString() {
    var str = ''
    if (this.state.type == 1) {
      str = 'RENDER THIS ONE CHIMNEY ON RIGHT'
    } else if (this.state.type == 2) {
      str = 'RENDER THIS ONE CHIMNEY ON LEFT'
    } else if (this.state.type == 4) {
      str = 'Santa LEFT'
    } else if (this.state.type == 5) {
      str = 'Santa RIGHT'
    }
    return str;
  }

  async uploadSuccess() {
    console.log('uploadSuccess called')
    var data = this.state.data;
    SQLiteManagerObject.insertSingleVideo(data.request, this.state.imageURI,this.moveToHistoryScreen);
 //   this.moveToHistoryScreen();
  }



  moveToHistoryScreen() {
    Orientation.lockToPortrait();
    setTimeout(() => {
      const resetAction = NavigationActions.reset({
        index: 1,
        actions: [
          NavigationActions.navigate({ routeName: 'EveScreen' }),
          NavigationActions.navigate({ routeName: 'VideoHistory' })
        ]
      })
      _this.props.navigation.dispatch(resetAction)
    }, 100)
  }


  uploadURLOnServer(location) {
    url = 'request';
    if (typeof this.state.giftBy !== 'undefined') {
      body = {
        "imageUrl": location,
        "composition": this.getSelectionString(),
      }
    } else if (typeof this.state.rowData === 'undefined') {
      body = {
        "imageUrl": location,
        "composition": this.getSelectionString(),
      }
    }
    else {
      body = {
        "imageUrl": location,
        "composition": this.getSelectionString(),
        //      "price":this.state.rowData.price,
        "originalRequestId": this.state.rowData.id,
        "isRetake": true
      }
    }

    token = this.props.navigation.state.params.authorization;
    ApiUtils.post(url, body, token).then(([response, data]) => {
      if (response.status === 200 || response.status === 201) {

        this.setState({ data: data });
        this.handleResponseAfterUploadImage(data);


      } else {
        this.stopLoading()
        Alert.alert('', '' + data.message)
      }
    }).catch((error) => {
      console.log('ERROR : ', error)
      this.stopLoading();
      Alert.alert('', error)
    })
  }

  getPrice(){
    var price = 0;
    if(this.state.type==1 || this.state.type==2){
      price = 9.99;
    }else if(this.state.type==4 || this.state.type==5){
      price = 4.99;
    }
    return price;
  }

  handleResponseAfterUploadImage(data) {
    //In case of gifted by someone
    if (typeof this.state.giftBy !== 'undefined') {
      var body = {
        "requestId": data.request.id,
        "price": data.request.price,
        "referalId": this.state.giftBy.id
      }
      _this.setState({body:body});
      _this.notifyPayment(body,false);
    }////In case of purchase
    else if (typeof this.state.rowData === 'undefined') {
      var body = {
        "requestId": data.request.id,
        "price": this.getPrice()//data.request.price,
      }
      _this.setState({body:body});
      _this.notifyPayment(body, this.state.isIAPEnable);
    }//// In case of retake
    else {
      this.stopLoading();
      this._showModal();
    }
  }

  notifyCall(paymentRes, productId){


    console.log('###### paymentRes=', paymentRes);
    var products_name_arr = [CONSTS.OPTION1, CONSTS.OPTION2, CONSTS.OPTION3, CONSTS.OPTION4];

    var purchased_product_name = products_name_arr[this.state.type>3?(this.state.type - 2):(this.state.type - 1)];


    if (Platform.OS == 'ios') {
      body =  {
              "requestId": this.state.body.requestId,
              "price": this.state.body.price,
              "referalId": this.state.body.referalId ? this.state.body.referalId : null,
              "transactionId": paymentRes != null ? paymentRes.transactionIdentifier : null,
              "productName": purchased_product_name,
              "purchaseDate": paymentRes != null ? new Date(paymentRes.transactionDate) : null,
              "productId": productId,
              "paymentMethod": null,
              "promoCode": null
            }
    } else {
      body =  {
              "requestId": this.state.body.requestId,
              "price": this.state.body.price,
              "referalId": this.state.body.referalId ? this.state.body.referalId : null,
              "transactionId": paymentRes != null ? paymentRes.purchaseToken : null,
              "productName": purchased_product_name,
              "purchaseDate": paymentRes != null ? new Date(paymentRes.purchaseTime) : null,
              "productId": productId,
              "paymentMethod": null,
              "promoCode": null
            }
    }

    url = 'payment/acknowledgement';
    token = this.props.navigation.state.params.authorization;
    ApiUtils.post(url, body, token).then(([response, data]) => {
      console.log(data);
      if (response.status === 200 || response.status === 201) {
                this.stopLoading()
                this._showModal()
      } else {
        this.stopLoading()
        Alert.alert('', '' + data.message)
      }
    }).catch((error) => {
      this.stopLoading();
      Alert.alert('', error)
    })
  }

  notifyPayment(body,direct) {
    if(!direct){
      _this.notifyCall(null, null);
    }else{
      //*> Proceed to payment
      _this.processPayment(body);
    }
  }


  componentWillMount() {
    const initial = Orientation.getInitialOrientation();
    if (initial === 'PORTRAIT') {
      // do something
    } else {
      // do something else
    }

    //*Checking on boarding display criteria
    AsyncStorage.getItem('OnBoardingMedia_Retake', (err, result) => {
      if (result != null) {
        this.setState({hasOnboardingMediaShown_retake:true});
      }
    })
  }

  componentDidMount() {
    var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
    trackerID.trackScreenView('GAME_PLAY');;
    Orientation.lockToLandscapeRight();
    Orientation.addOrientationListener(this._orientationDidChange);

    if (typeof this.props.navigation.state.params.viewDisplayCompletedCB != 'undefined') {
      this.props.navigation.state.params.viewDisplayCompletedCB()
    }

  }

  _orientationDidChange = (orientation) => {
    //alert('GAME '+orientation);
    if (orientation === 'LANDSCAPE') {
      // width = Dimensions.get('window').height;
      // height = Dimensions.get('window').width;
    } else {

    }
  }

  componentWillUnmount() {

    if (typeof this.props.navigation.state.params.orientationChangeCB != 'undefined') {
      this.props.navigation.state.params.orientationChangeCB()
    }

    Orientation.lockToPortrait();

    if (typeof this.props.navigation.state.params.onboardingEvent != 'undefined') {
      this.props.navigation.state.params.onboardingEvent.emit('ONBOARDING_EVENT')
    }

    Orientation.removeOrientationListener(this._orientationDidChange);

  }

  startLoading() {
    this.props.showLoader();
  }
  stopLoading() {
    this.props.hideLoader();
  }

}

const mapStateToProps = (state) => {
  return {

  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    showLoader: () => {
      dispatch(showLoader())
    }, hideLoader: () => {
      dispatch(hideLoader())
    }, setWidthHeight: (width, height) => {
      dispatch(setWidthHeight(width, height))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(GamePlay)
