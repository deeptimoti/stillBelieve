package com.cgs.teamworkar;

import android.graphics.Bitmap;

public interface OnBitmapCapture {
    public void onGetBitmap(Bitmap bitmap);
}
