import * as React from 'react'
import { connect } from 'react-redux';
import {
    View,
    Image,
    NativeModules,
    findNodeHandle,
    GestureResponderEvent,
    requireNativeComponent,
    DeviceEventEmitter,
    Dimensions,
} from 'react-native';
import { Container } from 'native-base'

import ViewShot from 'react-native-view-shot'

const ARView = requireNativeComponent('ARViewManager');
import Canvas from '../canvas'
import { setCurrentTool } from '../../../../store/session/actions'
import Commands from '../../interface/chat/utils/commands'

import { Cords } from './types';
import { Store } from '../../../../store';
import { SettingsState } from '../../../../store/session/types';
import { parseCords } from '../utils';
import { CurrentUserState } from '../../../../store/users/types';
import TwilioChat from '../../../../twilio/chat';

interface Props extends SettingsState {
    onPress(cords: Cords): void;
    currentUser: CurrentUserState,
    twilioChat: TwilioChat,
    twilioToken: string,
    twilioId: string,
    currentTool: string,
    setCurrentTool(name: string): void,
}

type State = {
    image?: string,
}

class Video extends React.Component<Props, State> {
    private ViewShot: any;
    private ARView: any;
    constructor(props: Props) {
        super(props);

        this.state = {
            image: undefined,
        }
    }

    componentDidMount() {
        const { twilioId, twilioToken, currentUser } = this.props;
        if (twilioToken) {
            var role = 'collaborator';
            if (twilioId === currentUser._id) {
                role = 'presenter';
            }

            NativeModules.ARModule.joinRoom(role, twilioId, twilioToken, findNodeHandle(this.ARView));
        }
        NativeModules.ARModule.changeDefaultColor('#33ccff', findNodeHandle(this.ARView));
    
        DeviceEventEmitter.addListener('onTapCords', this.onTapCords);
        DeviceEventEmitter.addListener('onScreenshot', this.setImage);
    }

    componentWillUnmount() {
        DeviceEventEmitter.removeListener('onTapCords', this.onTapCords);
        DeviceEventEmitter.removeListener('onScreenshot', this.setImage);
    }

    componentDidUpdate(previousProps: Props) {
        const { muted, currentTool } = this.props;

        if (previousProps.muted !== muted) {
            NativeModules.ARModule.toggleMute(muted, findNodeHandle(this.ARView));
        }

        if (currentTool && previousProps.currentTool !== currentTool) {
            // if (currentTool === 'camera') {
            //     this.captureView();
            // }

            //  now we are sending all tool name to native and in native 
            //  class we are handling only circle and arrow, other than these 
            //  two model will be null and will prompt to select an object
            NativeModules.ARModule.changeToolObjectModel(currentTool, findNodeHandle(this.ARView));
            // set min max Scale according to tool type
            switch (currentTool) {
                case 'circle':
                    NativeModules.ARModule.setMinMaxScale(currentTool, 0.1, 5, findNodeHandle(this.ARView));
                    break;
                case 'arrow':
                    NativeModules.ARModule.setMinMaxScale(currentTool, 0.5, 2, findNodeHandle(this.ARView));
                    break;
                case 'undo':
                    this.props.setCurrentTool('');
                    if (this.props.twilioId === this.props.currentUser._id) {
                        NativeModules.ARModule.undoAnchor(findNodeHandle(this.ARView));
                    } else {
                        this.props.twilioChat.sendCommand(`2undo`);
                    }
                    break;
                case 'redo':
                    this.props.setCurrentTool('');
                    if (this.props.twilioId === this.props.currentUser._id) {
                        NativeModules.ARModule.redoAnchor(findNodeHandle(this.ARView));
                    } else {
                        this.props.twilioChat.sendCommand(`2redo`);
                    }
                    break;
                case 'camera':
                    this.captureView();
                    break;
            }
            // you can use this method to change the color of the model
        }
    }

   

    render() {
        return (
            <Container>
                <ViewShot ref={(ref: any) => this.ViewShot = ref} options={{ format: 'png' }} style={{ position: 'absolute', width: '100%', height: '100%' }}>
                    <ARView ref={(ref: any) => this.ARView = ref} style={{ width: '100%', height: '100%', zIndex: -9999 }} />
                </ViewShot>
                <Canvas image={this.state.image}/> 
            </Container>
        )
    }

    captureView = () => {
        NativeModules.ARModule.videoCapture(findNodeHandle(this.ARView))
    }

    setImage = (image: string) => {
        this.setState({ image });
    }

    onTapCords = (cords: any) => {
        const { currentTool } = this.props; 
        
        if (currentTool) {
            const command = Commands.getCommand(this.props.currentTool, parseCords(cords));
            this.props.twilioChat.sendCommand(command);
        }
    }
}

const mapStateToProps = (state: Store) => ({
    currentUser: state.users.current,
    twilioChat: state.chat.twilioChat,
    twilioToken: state.twilio.token,
    twilioId: state.twilio.id,
    currentTool: state.session.toolbar.currentTool,
    ...state.session.settings
})

const mapDispatchToProps = {
    setCurrentTool
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Video)
