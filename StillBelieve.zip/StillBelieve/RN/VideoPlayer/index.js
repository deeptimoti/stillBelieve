/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableHighlight,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
  ScrollView,
  Picker,
  WebView,
  Platform
} from 'react-native';
//import styles from './styles'
import * as CONSTS from '@helper/consts'
import { StackNavigator } from 'react-navigation';
import { NavigationActions } from 'react-navigation'
const FBSDK = require('react-native-fbsdk');
const {
  LoginButton,
  AccessToken
} = FBSDK;
import Orientation from 'react-native-orientation';
import * as IMG from '@helper/ImgConst'
var { height, width } = Dimensions.get('window');
import ApiUtils from '@helper/ApiUtils'
import Validators from '@helper/Validators'
import * as CLR from '@helper/colors'
var Spinner = require('react-native-spinkit');
import Video from 'react-native-video';
import Header from '@Header'
var _this;

import VideoControlPlayer from 'react-native-video-controls';


export default class VideoPlayer extends Component {

  constructor(props) {

    super(props);
    _this = this;
    //console.log('',imageURL)
    // this.onLoad = this.onLoad.bind(this);
    // this.onProgress = this.onProgress.bind(this);
    // this.onError = this.onError.bind(this);
    // this.onBuffer = this.onBuffer.bind(this);
    console.ignoredYellowBox = ['Warning: ReactNative.createElement'];
    height = Dimensions.get('window').height;
    width = Dimensions.get('window').width;

    Orientation.unlockAllOrientations();
  }
 componentDidMount() {
    var trackerID=ApiUtils.getGoogleAnalyticsTrackerID();
    trackerID.trackScreenView('VIDEO_PLAYER');

    if (typeof this.props.navigation.state.params.viewDisplayCompletedCB != 'undefined') {
      this.props.navigation.state.params.viewDisplayCompletedCB()
    }
    
  }

  render() {
    const { imageURL } = this.props.navigation.state.params

    return (
        <VideoControlPlayer
          source={{ uri: imageURL }}
          navigator={ this.props.navigation }
        />
    );
  }

  componentWillUnmount() {
    Orientation.lockToPortrait();
  }

}
