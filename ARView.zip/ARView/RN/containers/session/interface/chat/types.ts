import { ImageURISource } from "react-native";

export type IMessage = {
    avatar?: ImageURISource,
    username: string,
    body: string,
    timestamp: string,
}