package com.cgs.teamworkar;

import android.content.Context;
import android.graphics.Bitmap;

import org.webrtc.EglRenderer;

public class ImageListener implements EglRenderer.FrameListener {
    Context mContext;
    public ImageListener(Context context){
        this.mContext = context;
    }

    @Override
    public void onFrame(Bitmap bitmap) {
        Utill.showToast(mContext,"onFrame");
    }


}

