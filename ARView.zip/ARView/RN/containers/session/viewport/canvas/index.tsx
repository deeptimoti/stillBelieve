import * as React from 'react'
import { connect } from 'react-redux';
import { StyleSheet, Image } from 'react-native'
import { Container } from 'native-base';

//@ts-ignore
import { SketchCanvas } from '@terrylinla/react-native-sketch-canvas';

import actions from '../../interface/toolbar/assets/actions';

import { Store } from '../../../../store';

type Props = {
  image?: string,
}

class Canvas extends React.Component<Props> {
  constructor(props: Props) {
    super(props);
  }

  render() {
    const { image } = this.props;
    console.log('image: ', image)

    return (
      <Container style= {styles.container}>  
          <Image source={{ uri: `data:image/png;base64,${image}`}} style={{ position: 'absolute', width: '100%', height: '100%' }}/>
          <SketchCanvas
            style={[styles.container]}
            strokeColor={'red'}
            strokeWidth={7}
          />      
      </Container>
    )
  }
}

const mapStateToProps = (state: Store) => ({
  ...state.session.settings,
})

const mapDispatchToProps = {
  
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Canvas)

const styles = StyleSheet.create({
  container: {
      position:'absolute',
      width:'100%',
      height: '100%',
      backgroundColor: 'transparent'
  }
});