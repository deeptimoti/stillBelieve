import * as React from 'react'
import { ListItem, Body, Left, Thumbnail, Right, Text } from "native-base"
//@ts-ignore
import styled from 'styled-components/native';

const defaultAvatar = require('../../../../assets/misc/avatar.png');

import { IMessage } from "./types"
import { StyleSheet } from 'react-native';

export const Notification = (props: { message: string }) => (
    <ListItem avatar style={styles.notification}>
        <Body>
            <Text>{props.message}</Text>
        </Body>
    </ListItem>
)

export const Image = () => {
    
}

export const MessageIncoming = (props: IMessage) => (
    <ListItem avatar style={styles.itemLeft}>
        <Left>
            <Thumbnail source={props.avatar ? props.avatar : defaultAvatar} />
        </Left>
        <Body>
            <Text style={{fontWeight: 'bold'}}>{props.username}</Text>
            <Text>{props.body}</Text>
        </Body>
        <Right>
            <Text note>{props.timestamp}</Text>
        </Right>
    </ListItem>
)

export const MessageOutgoing = (props: IMessage) => (
    <ListItem avatar style={styles.itemRight}>
        <Left style={{alignItems: 'center', justifyContent: 'center'}}>
            <Thumbnail source={props.avatar ? props.avatar : defaultAvatar} />
        </Left>
        <Body>
            <Text style={{fontWeight: 'bold'}}>{props.username}</Text>
            <Text>{props.body}</Text>
        </Body>
        <Right>
            <Text note>{props.timestamp}</Text>
        </Right>
    </ListItem>
)

const styles = StyleSheet.create({
    itemLeft: {
        flex: 1,
        width: '60%',
        backgroundColor: '#fff',
        alignItems: 'center',
        alignSelf: 'flex-start',
        justifyContent: 'center',
        marginTop: 5,
        marginBottom: 5,
        marginLeft: 10,
    },
    itemRight: {
        width: '60%',
        backgroundColor: '#fff',
        alignItems: 'center',
        alignSelf: 'flex-end',
        justifyContent: 'center',
        marginTop: 5,
        marginRight: 10,
        marginBottom: 5,
    },
    notification: {
        width: '100%',
        backgroundColor: 'transparent',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 10,
        marginBottom: 10,
    }
})
