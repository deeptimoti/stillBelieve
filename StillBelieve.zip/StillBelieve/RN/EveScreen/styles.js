import {
  StyleSheet,
} from 'react-native';
import { getCorrectFontSizeForScreen } from '@helper/multiResolution'
import * as CLR from '@helper/colors';
import * as CONSTS from '@helper/consts'


const styles = StyleSheet.create({
  comingSoonContainer: {
    padding: 8,
    marginLeft: 2,
    marginRight: 2,
    borderBottomLeftRadius: 5,
    borderBottomRightRadius: 5,
    left: 0,
    right: 0,
    position: 'absolute',
    bottom: 0,
    alignSelf: 'stretch',
    backgroundColor: '#00000080',
    alignItems: 'center'
  },commingSoonText:{
      color:'white',
      fontSize:getCorrectFontSizeForScreen(12),
     fontFamily: CONSTS.REGULAR_FONT,
  },eveTitle:{
    color:'white',
    fontSize:getCorrectFontSizeForScreen(20),
   fontFamily: CONSTS.REGULAR_FONT,
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  headerTitle: {
    color: '#fff',
    fontSize: getCorrectFontSizeForScreen(18),
    alignSelf: 'center',
   fontFamily: CONSTS.REGULAR_FONT,
    textAlign: 'center'
  },
  bgImageStyle: {

  },
  upperContainer: {
    paddingTop: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: CLR.APP_BLUE
  },
  lowerContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  menuItemContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 1,
    backgroundColor: '#0a5a99',
    alignSelf: 'stretch',
    padding: 5
  },
  upperMenuTitle: {
    color: '#fff',
    fontSize: getCorrectFontSizeForScreen(15),
    alignSelf: 'center',
    fontFamily: CONSTS.REGULAR_FONT,
  },
  lowerMenuTitle: {
    color: '#a5b9d0',
    fontSize: getCorrectFontSizeForScreen(13),
    alignSelf: 'center',
    textAlign: 'center',
    fontFamily: CONSTS.REGULAR_FONT,

  },
});
export default styles;
