/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableHighlight,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Platform,
  AsyncStorage,
  AppState
} from 'react-native';
import styles from './styles'
import * as CONSTS from '@helper/consts'
import { StackNavigator } from 'react-navigation';
import Orientation from 'react-native-orientation';
import { getCorrectFontSizeForScreen } from '@helper/multiResolution'
import * as IMG from '@helper/ImgConst'
import * as CLR from '@helper/colors'
import RedeemGift from '@RedeemGift'
import {getFeedback} from '@store/modules/feedback/actions'
import {getNotifications} from '@store/modules/notification/actions'
import ApiUtils from '@helper/ApiUtils'
import { connect } from 'react-redux'
import FCM from 'react-native-fcm';
import { NavigationActions } from 'react-navigation'

var _this;

 class EveScreen extends Component {

  constructor(props) {
    super(props);
    _this = this;
     this.state = {
      token: "",
      tokenCopyFeedback: "",
    }
    console.ignoredYellowBox = ['Warning: ReactNative.createElement'];
     _this.props.getNotifications(_this.props.userDetails.authorization);
  }

  componentWillReceiveProps(nextProps){
    if (nextProps.screenName != '') {
      if(AppState.currentState === 'active') {
        if (ApiUtils.getCurrentScreen() == nextProps.screenName || nextProps.isFromTray) {
          this.navigateNotification(nextProps.screenName)
        }
      } else{
        this.navigateNotification(nextProps.screenName)
      }
    }
  }

  componentDidMount() {

    var trackerID=ApiUtils.getGoogleAnalyticsTrackerID();
    trackerID.trackScreenView('EVE_SCREEN');
    Orientation.lockToPortrait();
    Orientation.addOrientationListener(this._orientationDidChange);

    FCM.getFCMToken().then(token => {
      console.log('FCM TOKEN MAINMENU : ', token)
      this.setState({ token: token });
      this.uploadFCMToken(this.props.userDetails.authorization,token);
    });

  }

  render() {

    var iOSTop = Platform.OS == 'ios' ? 25 : 0
    return (
      <View style={styles.container}>
        <StatusBar
         backgroundColor={CLR.APP_BLUE}
       />
        <View>
          <View style={styles.upperContainer}>
            <View style={{ alignSelf: 'stretch' }}>
              <Text style={[styles.headerTitle, { fontSize: getCorrectFontSizeForScreen(20), marginTop: iOSTop }]}>Making Memories</Text>
              <Text style={[styles.headerTitle, {color:CLR.SMALL_HEADER_TEXT, fontSize: getCorrectFontSizeForScreen(12), marginTop: 5, marginBottom: 20 }]}>You simply take a picture and Still Believe will{'\n'}capture one of the below mythical characters{'\n'}in your home and deliver you a video!{'\n'}{'\n'}Please choose the memory{'\n'}we can help you create for your child.</Text>
            </View>
             <ScrollView style={{alignSelf:'stretch',backgroundColor:'white'}}>
          <View style={{ flexDirection: 'row', alignSelf: 'center', marginTop: 10,backgroundColor:'white' }}>
            <TouchableOpacity onPress={()=>this.reset()} style={{ margin: 0 }}>
              <Image style={{ alignItems: 'center', justifyContent: 'center' }} source={IMG.CHRISTMAS_EVE}>
              </Image>
            </TouchableOpacity>
            <TouchableOpacity style={{ margin: 0 }}>
            <Image style={{ alignItems: 'center', justifyContent: 'center' }} source={IMG.TOOTHFAIRY_EVE}>
            </Image>
          </TouchableOpacity>
          </View>
          <View style={{ flexDirection: 'row', alignSelf: 'center',marginBottom:60 }}>
          <TouchableOpacity style={{ marginRight: 0 }}>
          <Image style={{ alignItems: 'center', justifyContent: 'center' }} source={IMG.CUPID_EVE}>
          </Image>
        </TouchableOpacity>
        <TouchableOpacity style={{ marginLeft: 0,marginBottom:60 }}>
        <Image style={{ alignItems: 'center', justifyContent: 'center' }} source={IMG.EASTER_EVE}>
        </Image>
      </TouchableOpacity>
       </View>
          </ScrollView>
          </View>
        </View>
        <TouchableOpacity onPress={()=>this.openDrawer()} style={{padding: 10,position:'absolute',top:iOSTop}}><Image source={IMG.MENU}/></TouchableOpacity>
          <RedeemGift navigator={this.props.navigation}/>
      </View>
    );
  }
  openDrawer(){
    this.props.navigation.navigate('DrawerOpen')
  }

  reset() {
      this.props.navigation.navigate("MainMenu");
  }

  moveAhead(type) {
    this.props.navigation.navigate("GamePlay", { type: type });
  }

  uploadFCMToken(authorization,token) {
       if(typeof authorization==='undefined'){
         return
       }
       url = 'deviceToken';
       body = {
         "token": token,
         "deviceType": Platform.OS
       }
       ApiUtils.post(url, body, authorization).then(([response, data]) => {
         console.log('deviceToken : ', response)
       }).catch((error) => {
         console.log('ERROR : ', error)
       })
   }

  componentWillMount() {
    const initial = Orientation.getInitialOrientation();
    if (initial === 'PORTRAIT') {
      // do something
    } else {
      // do something else
    }
  }

  _orientationDidChange = (orientation) => {

  }

  componentWillUnmount() {

    Orientation.getOrientation((err, orientation) => {
    });
    Orientation.removeOrientationListener(this._orientationDidChange);
  }

  navigateNotification(landingScreen){
     return _this.props
      .navigation
      .dispatch(NavigationActions.reset(
        {
          index: 1,
          actions: [
             NavigationActions.navigate({ routeName: 'EveScreen'}),
             NavigationActions.navigate({ routeName: landingScreen})
          ]
        }));
  }
}

const mapStateToProps = (state) => {
  return {
    width: state.common.width,
    height: state.common.height,
    isLoading: state.common.isLoading,
    userDetails: state.auth.userDetails,
    screenName:state.notification.screenName,
    isFromTray:state.notification.isFromTray
  }
}


const mapDispatchToProps = (dispatch) => {
  return {
    showLoader: () => {
      dispatch(showLoader())
    },hideLoader: () => {
      dispatch(hideLoader())
    },setWidthHeight: (width,height) => {
      dispatch(setWidthHeight(width,height))
    }, getFeedback: (authorization) => {
      dispatch(getFeedback(authorization))
    },getNotifications: (authorization) => {
      dispatch(getNotifications(authorization))
    }

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(EveScreen)
