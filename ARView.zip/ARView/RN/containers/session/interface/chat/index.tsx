import * as React from 'react'
import { connect } from 'react-redux';
import { ScrollView, TextInput, StyleSheet, KeyboardAvoidingView, TouchableWithoutFeedback, View } from 'react-native';
import { Container, List, Thumbnail, Text, Button } from 'native-base';
import { Notification, MessageOutgoing, MessageIncoming } from './messages';

import Invite from '../../../../components/invite';

const sendIcon = require('../../../../assets/buttons/send.png');
const sendIconTap = require('../../../../assets/buttons/send-tap.png');

import { toggleChat } from '../../../../store/chat/actions'

import { ChatState, ChatMessage } from '../../../../store/chat/types';
import { Store } from '../../../../store';
import { CurrentUserState } from '../../../../store/users/types';

interface Props extends ChatState {
  toggleChat(bool?: boolean): void,
  groupExperts: any[],
  groupUsers: any[],
  twilioId: string,
  currentUser: CurrentUserState,
  messages: (ChatMessage | string)[],
}

type State = {
  message: string,
  inviteModal: boolean,
}

class Chat extends React.Component<Props, State> {
  private messageList: React.RefObject<ScrollView>;
  constructor(props: Props) {
    super(props);

    this.state = {
      message: '',
      inviteModal: false,
    }

    this.messageList = React.createRef();
  }

  render() {
    const { connected, loaded, messages, isTyping, groupUsers, groupExperts, twilioId, currentUser } = this.props;
    console.log(messages);

    const messageItems: any[] = [];
    messages.forEach((message, i) => {
      if (typeof message === 'string') {
         messageItems.push(<Notification message={message} key={i} />)
      } else if (message.username === 'You') {
        messageItems.push(<MessageOutgoing {...message} key={i} />)
      } else {
        //Please fix this mess. Should get all users with limited fields from API.
        const _message = Object.assign({}, message);
        if (groupUsers) {
          const user = groupUsers.filter(user => user._id === message.username)[0];
          _message.username = user.fullName
        } else if (groupExperts) {
          const user = groupExperts.filter(user => user._id === message.username)[0];
          _message.username = user.fullName;
        }
        messageItems.push(<MessageIncoming {..._message} key={i} />)
      }
    })

    const InviteModal = () => {
      if (twilioId === currentUser._id) {
        return (
          <Invite
            inSession={true}
            isVisible={this.state.inviteModal}
            callback={() => this.toggleInviteModal(false)}
            close={() => this.toggleInviteModal(false)}
            users={currentUser.role === 'expert' ? this.props.groupUsers : this.props.groupExperts}
            sessionId={currentUser._id}
          />
        )
      }
      return null;
    }

    const InviteButton = () => {
      if (twilioId === currentUser._id) {
        return (
          <Button onPress={() => this.toggleInviteModal(true)} style={styles.inviteBtn} >
            <Text style={{ fontSize: 16 }}>Invite Users</Text>
          </Button>
        )
      }
      return null;
    }

    return (
      <Container style={styles.container}>
        <InviteModal />
        <Container style={styles.header}>
          <View style={{ flex: 1 }}>
          </View>
          <View style={{ flex: 1 }}>
            <InviteButton />
          </View>
          <View style={{ flex: 1 }}>
            <Button transparent onPress={() => this.handleChatClose()} style={styles.close} >
              <Thumbnail source={require('../../../../assets/buttons/close.png')} />
            </Button>
          </View>
        </Container>
        <Container style={styles.body}>
          {connected ?
            <ScrollView
              ref={this.messageList}
              onContentSizeChange={() => this.messageList.current ? this.messageList.current.scrollToEnd() : null}
            >
              <List >
                {messageItems}
              </List>
            </ScrollView>
            :
            <Text style={{ fontSize: 32, alignSelf: 'center', color: '#fff' }}>Not connected to chat.</Text>}
        </Container>
        <Container style={styles.footer}>
          {/* <Text>{isTyping ? "User is typing..." : null}</Text> */}
          <TextInput
            editable={connected}
            style={styles.input}
            onChangeText={(text) => {
              this.handleInput(text)
            }}
            value={this.state.message}
          />
          <TouchableWithoutFeedback onPressIn={() => this.sendMessage()}>
            <Thumbnail source={connected ? sendIcon : sendIconTap} style={styles.sendBtn} />
          </TouchableWithoutFeedback>
        </Container>
      </Container>
    )
  }

  handleChatClose() {
    this.props.toggleChat()
  }

  handleInput(text: string) {
    this.setState({ message: text });

    const { twilioChat } = this.props
    if (twilioChat) {
      twilioChat.notifyTyping();
    }
  }

  toggleInviteModal(bool?: boolean) {
    this.setState({ inviteModal: (bool ? bool : !this.state.inviteModal) })
  }

  sendMessage() {
    const { message } = this.state;
    const { twilioChat } = this.props;

    if (message && twilioChat) {
      twilioChat.sendMessage(message);
      this.setState({ message: '' });
    }
  }
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: 'transparent'
  },
  header: {
    flex: 1,
    maxHeight: 60,
    alignItems: 'center',
    flexDirection: 'row',
    backgroundColor: 'rgba(50, 50, 50, 0.65)',
  },
  body: {
    justifyContent: 'center',
    backgroundColor: 'rgba(50, 50, 50, 0.65)'
  },
  footer: {
    flex: 1,
    maxHeight: 60,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#C3C3C3',
  },
  messages: {

  },
  input: {
    flex: 1,
    height: 40,
    marginLeft: 20,
    backgroundColor: '#F4F4F4',
    fontSize: 18,
  },
  sendBtn: {
    margin: 15,
    height: 50,
    width: 50,
  },
  inviteBtn: {
    alignSelf: 'center',
    backgroundColor: '#7C91EC'
  },
  close: {
    paddingRight: 10,
    marginLeft: 'auto',
    alignSelf: 'center',
    backgroundColor: 'transparent',
  }
})

const mapStateToProps = (state: Store) => ({
  ...state.chat,
  participants: state.session.participants,
  groupUsers: state.users.groupUsers,
  groupExperts: state.users.groupExperts,
  twilioId: state.twilio.id,
  currentUser: state.users.current,
})

const mapDispatchToProps = {
  toggleChat,
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Chat)