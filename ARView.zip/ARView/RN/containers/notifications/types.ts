export type TwilioNotifyInvite = {
    twi_body: string,
    twi_message_id: string,
    room: string,
    twi_title: string,
}