/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableHighlight,
  Image,
  TouchableOpacity,
  TextInput,
  Alert,
  ScrollView,
  AsyncStorage,
  Platform,
  StatusBar,
  NetInfo
} from 'react-native';
import styles from './styles'
import * as CONSTS from '@helper/consts'
import { StackNavigator } from 'react-navigation';
import { NavigationActions } from 'react-navigation'
const FBSDK = require('react-native-fbsdk');
import { LoginManager } from 'react-native-fbsdk'
import { showLoader, hideLoader, setWidthHeight } from '@store/modules/common/actions'
import { GoogleSignin, GoogleSigninButton } from 'react-native-google-signin';
const {
  LoginButton,
  AccessToken
} = FBSDK;
import Orientation from 'react-native-orientation';
import * as IMG from '@helper/ImgConst'
var { height, width } = Dimensions.get('window');
import ApiUtils from '@helper/ApiUtils'
import Validators from '@helper/Validators'
import * as CLR from '@helper/colors'
var Spinner = require('react-native-spinkit');
import { connect } from 'react-redux'
import { setUserData } from '@store/modules/auth/actions'
var _this;
import Header from '@Header'
import { showUpgradeMessage } from '@store/modules/notification/actions'

class SignUp extends Component {
  constructor(props) {
    super(props);
    console.log('123456', this.props.navigation.state.params.width);
    _this = this;
    this.state = {
      emailStr: '',
      passwordStr: '',
      confirmPasswordStr: '',
      isLoading: false,
      width: this.props.navigation.state.params.width,
      height: this.props.navigation.state.params.height
    }

    //  this.state = {
    //     emailStr: 'ss@s.com',
    //     passwordStr: '123456',
    //     confirmPasswordStr: '123456',
    //     isLoading:false
    //   }

    console.ignoredYellowBox = ['Warning: ReactNative.createElement'];
    height = Dimensions.get('window').height;
    width = Dimensions.get('window').width;
  }
  renderLoading() {
    if (this.state.isLoading) {
      return (
        <View style={{ position: 'absolute', width: width, height: height, alignItems: 'center', justifyContent: 'center', backgroundColor: '#00000080', marginTop: -56 }}>
          <Spinner style={styles.spinner} isVisible={this.state.isLoading} size={100} type={'Circle'} color={'#0a5a99'} />
        </View>
      );
    } else {
      return null;
    }

  }
  render() {
    return (
      <ScrollView keyboardShouldPersistTaps={'handled'} style={{ width: width, height: height, backgroundColor: 'white' }}>
        <View style={styles.container}>
          <StatusBar
         backgroundColor={CLR.APP_BLUE}
       />
  {this.renderHeader()}

          <View style={{ marginTop: 10 }} />
          <TextInput keyboardType={'email-address'}
          autoCapitalize="none" returnKeyType={"next"} onSubmitEditing={(event) => {
            this.refs.password.focus();
          }} underlineColorAndroid='transparent' value={this.state.emailStr} style={[styles.inputBox, { width: this.state.width,height:this.state.height }]} placeholder={'Email'} onChangeText={(text) => this.setState({ emailStr: text })} />
          <TextInput returnKeyType={"next"} ref='password' onSubmitEditing={(event) => {
            this.refs.confirm_password.focus();
          }} underlineColorAndroid='transparent' value={this.state.passwordStr} style={[styles.inputBox, { width: this.state.width,height:this.state.height }]} placeholder={'Password'} secureTextEntry={true} onChangeText={(text) => this.setState({ passwordStr: text })} />
          <TextInput onSubmitEditing={(event) => {
            this.signUp()
          }} returnKeyType={"go"} ref='confirm_password' underlineColorAndroid='transparent' value={this.state.confirmPasswordStr} style={[styles.inputBox, { width: this.state.width,height:this.state.height }]} placeholder={'Confirm Password'} secureTextEntry={true} onChangeText={(text) => this.setState({ confirmPasswordStr: text })} />

          {this.renderSignUpButton()}
          {/*<TouchableOpacity onPress={() => this.signUp()} style={{ marginTop: 20 }}>
          <Image source={IMG.SIGN_UP}></Image>
        </TouchableOpacity>*/}



          <Image style={{ marginTop: 20 }} source={IMG.OR_LINE}></Image>

          <View style={{ flexDirection: 'row', marginHorizontal: 30 }}>
            <TouchableOpacity onPress={() => this.handleFacebookLogin()} style={{ marginTop: 20 }}>
              <Image source={IMG.FB_SIGNIN}></Image>
            </TouchableOpacity>

            <View style={{ width: 20 }} />

            <TouchableOpacity onPress={() => this._signIn()} style={{ marginTop: 20 }}>
              <Image source={IMG.G_PLUS_SIGNIN}></Image>
            </TouchableOpacity>


          </View>

          <View style={{ flexDirection: 'row', marginTop: 30 }}>
            <Text style={styles.dontHave}>Already have an account?</Text>
            <TouchableOpacity onPress={() => this.props.navigation.goBack()} style={{ backgroundColor: 'transparent' }}><Text style={styles.signupNow}> Login</Text></TouchableOpacity>
          </View>
          {this.renderLoading()}
        </View>
      </ScrollView>
    );
  }

  renderSignUpButton() {
    return (
      <TouchableOpacity onPress={() => this.signUp()} style={{ margin: 20, marginTop: 30, alignItems: 'center', justifyContent: 'center', backgroundColor: CLR.APP_BLUE, padding: 10, borderRadius: 25, width: this.state.width,height:this.state.height }}>
        <Text style={styles.signupText}>SIGN UP</Text>
      </TouchableOpacity>
    )
  }

   renderHeader() {
    return (<Header title={'Create a new account'} backButton={true} leftCallback={() => this.onPressGoBack()} rightTitle={this.state.currentView == 'list' ? 'Card View' : 'List View'} rightCallback={() => this.changeCurrentView()} navigator={this.props.navigation} />)
  }

  initUser(token) {
    fetch('https://graph.facebook.com/v2.5/me?fields=email,name,friends&access_token=' + token)
      .then((response) => response.json())
      .then((json) => {
        console.log('hey : ', json);
        Alert.alert('', 'Welcome ' + json.name);
      })
      .catch(() => {
        //reject('ERROR GETTING DATA FROM FACEBOOK')
      })
  }

  reset() {
    return this.props
      .navigation
      .dispatch(NavigationActions.reset(
        {
          index: 0,
          actions: [
            NavigationActions.navigate({ routeName: 'EveScreen' })
          ]
        }));
  }


  componentWillMount() {
    const initial = Orientation.getInitialOrientation();
    if (initial === 'PORTRAIT') {
      // do something
    } else {
      // do something else
    }
  }

  componentDidMount() {
    var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
    trackerID.trackScreenView('SIGN_UP');
    this._setupGoogleSignin();
    Orientation.lockToPortrait();
    Orientation.addOrientationListener(this._orientationDidChange);
  }

  _orientationDidChange = (orientation) => {
    if (orientation === 'LANDSCAPE') {
    } else {
    }
  }

  componentWillUnmount() {
    Orientation.getOrientation((err, orientation) => {
      console.log(`Current Device Orientation: ${orientation}`);
    });
    Orientation.removeOrientationListener(this._orientationDidChange);
  }



  isValidate() {
    if (this.state.emailStr == '') {
      Alert.alert('', 'Please enter your email');
      return false;
    } else if (!Validators.validEmail(this.state.emailStr)) {
      Alert.alert('', 'Please enter valid email');
      return false;
    } else if (this.state.passwordStr == '') {
      Alert.alert('', 'Please enter password');
      return false;
    } else if (this.state.passwordStr.length < 6) {
      Alert.alert('', 'Password length must be at least 6 characters long');
      return false;
    } else if (this.state.confirmPasswordStr.length == '') {
      Alert.alert('', 'Please enter confirm password');
      return false;
    } else if (this.state.confirmPasswordStr != this.state.passwordStr) {
      Alert.alert('', 'Passwords not matching');
      return false;
    }
    return true;
  }


  signUp() {
    if (this.isValidate()) {
      this.startLoading();
      url = 'userSignup';
      body = {

        "password": this.state.passwordStr,
        "email": this.state.emailStr,
      }
      token = 'token';
      ApiUtils.post(url, body, token).then(([response, data]) => {
        this.stopLoading();
        console.log('@@@@@@ LOGIN STATUS', response)
        if (response.status === 200 || response.status === 201) {
          Alert.alert('', 'You have signed up successfully');
          var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
          trackerID.trackEvent('Signed_up', 'Normarl');

          var authorization = response.headers.map.authorization[0];
          this.saveUserInfo(authorization, data.userDetails)
        } else {

          if (response.status == 301) {
            this.props.showUpgradeMessage()
            return;
          }
          
          Alert.alert('', data.message);
        }
      }).catch((error) => { this.stopLoading(); console.log('ERROR : ', error); Alert.alert(error.message) })
    }
  }
  startLoading() {
    //this.setState({isLoading:true});
    this.props.showLoader();
  }

  stopLoading() {
    //this.setState({isLoading:false});
    this.props.hideLoader()
  }


  handleFacebookLogin() {
     NetInfo.isConnected.fetch().then(isConnected => {
          if(isConnected){
    LoginManager.logInWithReadPermissions(['public_profile', 'email', 'user_friends']).then(
      function (result) {
        console.log('jklajsdf klj', result)
        if (result.isCancelled) {
          console.log('Login cancelled')
        } else {
          console.log('Login success with permissions: ' + result.grantedPermissions.toString())
          AccessToken.getCurrentAccessToken().then((data) => {
            const { accessToken } = data

            fetch(`https://graph.facebook.com/me?access_token=${data.accessToken.toString()}`)
              .then((response) => response.json())
              .then((res) => {
                console.log(" res : ", res);
                var socialOptions = {
                  email: res.email,
                  name: res.name,
                  lastName: res.last_name,
                  accessToken: data.accessToken.toString(),
                  id: data.userID,
                  loginType: 'facebook',
                }
                //alert(JSON.stringify(socialOptions))
                _this.socialLoginFacebook(socialOptions)
              })
              .catch((err) => console.log('error occurred', err.message));
          })
        }
      },
      function (error) {
        console.log('Login fail with error: ' + error)
      }
    )
          }else{
Alert.alert('','Network Request Failed');
          }
     })


  }

  initUser(token) {
    fetch('https://graph.facebook.com/v2.5/me?fields=email,name,friends&access_token=' + token)
      .then((response) => response.json())
      .then((json) => {
        console.log('hey : ', json);
        Alert.alert('', 'Welcome ' + json.name);
      })
      .catch(() => {
        //reject('ERROR GETTING DATA FROM FACEBOOK')
      })
  }

  reset(authorization) {
    //   this.props.navigation.navigate("SignUp");
    console.log('authorization : ', authorization);
    return this.props
      .navigation
      .dispatch(NavigationActions.reset(
        {
          index: 0,
          actions: [
            NavigationActions.navigate({ routeName: 'EveScreen',params:{abc:'abc',authorization:authorization}})
          ]
        }));
  }

  saveUserInfo(authorization, userDetails) {
    var user = { authorization: authorization, user_name: 'shahid' }
    AsyncStorage.setItem('user', JSON.stringify(user), () => {
      this.reset(authorization);
    });
    userDetails.authorization = authorization
    this.props.setUserData({ userDetails: userDetails });
    AsyncStorage.setItem('userDetails', JSON.stringify(userDetails), () => {

    });
  }

  _setupIOS() {
    GoogleSignin.configure({
      iosClientId: '803876623167-ogvc7fjcts7csjhu7kgfftucdqovqvrc.apps.googleusercontent.com',
      webClientId: '803876623167-ogvc7fjcts7csjhu7kgfftucdqovqvrc.apps.googleusercontent.com',
      offlineAccess: false
    })
    console.log('LoginComponent _setupIOS');
  }
  _setupAndroid() {
    GoogleSignin.configure({
      webClientId: '803876623167-59mhaf1p3d5msn95nc4i4fsqb90t5d0f.apps.googleusercontent.com',
      offlineAccess: false
    });
    console.log('LoginComponent _setupAndroid');
  }


  async _setupGoogleSignin() {
    try {
      console.log('LoginComponent etupGoogleSignin');
      await GoogleSignin.hasPlayServices({ autoResolve: true });
      Platform.OS === 'android' ?
        await this._setupAndroid()
        : await this._setupIOS()
      const user = await GoogleSignin.currentUserAsync();
      console.log(user);

      this.setState({ user });
    }
    catch (err) {
      console.log("LoginComponent Play services error", err.code, err.message);
    }

  }

  socialLoginG_Plus(user) {
    {
      var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
      trackerID.trackEvent('Signed_up', 'GooglePlus');
      this.startLoading();
      url = 'socialLogin';
      body = {
        "auth": user.accessToken,
        "loginType": 'google',
        "email": user.email,
        "socialId": user.id,
        "profileImage": user.photo,
        "name": user.name
      }
      token = 'token';
      ApiUtils.post(url, body, token).then(([response, data]) => {
        this.stopLoading();
        //console.log('@@@@@@ LOGIN STATUS', response.headers.map.authorization[0])

        if (response.status === 200 || response.status === 201) {
          var authorization = response.headers.map.authorization[0];
          this.saveUserInfo(authorization, data.userDetails)
        } else {

          if (response.status == 301) {
            this.props.showUpgradeMessage()
            return;
          }

          try {
            Alert.alert('', data.message);
          } catch (error) {
            Alert.alert('Server Error');
          }
        }
      }).catch((error) => { this.stopLoading(); console.log('ERROR : ', error); Alert.alert(error.message) })
    }
  }
  socialLoginFacebook(user) {
    var trackerID = ApiUtils.getGoogleAnalyticsTrackerID();
    trackerID.trackEvent('Signed_up', 'Facebook');
    console.log('socialLoginFacebook123', user);
    {
      this.startLoading();
      url = 'socialLogin';
      body = {
        "auth": user.accessToken,
        "loginType": 'facebook',
        "socialId": user.id,
        "name": user.name
      }
      token = 'token';
      ApiUtils.post(url, body, token).then(([response, data]) => {
        this.stopLoading();
        //console.log('@@@@@@ LOGIN STATUS', response.headers.map.authorization[0])

        if (response.status === 200 || response.status === 201) {
          var authorization = response.headers.map.authorization[0];
          this.saveUserInfo(authorization, data.userDetails)
        } else {

          if (response.status == 301) {
            this.props.showUpgradeMessage()
            return;
          }

          try {
            Alert.alert('', data.message);
          } catch (error) {
            Alert.alert('Server Error');
          }
        }
      }).catch((error) => { this.stopLoading(); console.log('ERROR : ', error); Alert.alert(error.message) })
    }
  }

  _signIn() {
    console.log('LoginComponent _signIn()');

    GoogleSignin.signIn()
      .then((user) => {
        console.log(user);
        this.setState({ user: user });
        this.socialLoginG_Plus(user);
        console.log('LoginComponent _signIn success ');
      })
      .catch((err) => {
        console.log('LoginComponent WRONG SIGNIN', err);
      })
      .done();
  }

  _signOut() {
    GoogleSignin.revokeAccess().then(() => GoogleSignin.signOut()).then(() => {
      this.setState({ user: null });
    })
      .done();
  }

}

const mapStateToProps = (state) => {
  return {
    loggedIn: state.auth.loggedIn,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    setUserData: (userData) => {
      console.log('789456123', userData)
      dispatch(setUserData(userData))
    }, showLoader: () => {
      dispatch(showLoader())
    }, hideLoader: () => {
      dispatch(hideLoader())
    }, setWidthHeight: (width, height) => {
      dispatch(setWidthHeight(width, height))
    }, showUpgradeMessage: () => {
      dispatch(showUpgradeMessage())
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(SignUp)
