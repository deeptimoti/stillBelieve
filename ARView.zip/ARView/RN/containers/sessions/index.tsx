import * as React from 'react'
import { connect } from 'react-redux';
import { Container, Tabs, Tab, Icon } from 'native-base';
import { NavigationScreenProps, NavigationScreenProp } from 'react-navigation';
import { AndroidBackHandler } from 'react-navigation-backhandler';
import Orientation from 'react-native-orientation'

import Notifications from '../notifications'
import Invite from '../../components/invite'
import Pending from './pending'
import Completed from './completed'
import Searchbar from '../../components/searchbar';

import { getToken, tokenReset } from '../../store/twilio/actions';

import { Store } from '../../store';
import { StatusBar, StyleSheet, TouchableNativeFeedback } from 'react-native';
import { CurrentUserState } from '../../store/users/types';``

type Props = {
  navigation: NavigationScreenProp<any>,
  currentUser: CurrentUserState,
  groupUsers: any,
  groupExperts: any,
  authToken: string
  twilioToken: string,
  getToken(authToken: string, identity: string): Promise<any>,
  tokenReset(): void,
}

type State = {
  inviteModal: boolean,
  searchText: string,
}

class Sessions extends React.Component<Props, State> {
  static navigationOptions = ({ navigation }: NavigationScreenProps) => {
    const openModal = navigation.getParam('openModal');

    return {
      title: 'Sessions',
      headerLeft: () => (
        <TouchableNativeFeedback onPress={openModal}>
          <Icon name="plus" type='MaterialCommunityIcons' style={{ paddingLeft: 15, color: '#fff' }} />
        </TouchableNativeFeedback>
      )
    }
  }

  constructor(props: Props) {
    super(props);

    this.state = {
      inviteModal: false,
      searchText: '',
    }

    StatusBar.setBackgroundColor('#2E2f39');
    props.tokenReset();
  }

  componentDidMount() {
    Orientation.unlockAllOrientations();
    this.props.navigation.setParams({ openModal: () => this.toggleModal() })
  }

  componentDidUpdate(prevProps: Props) {
    if (this.props.twilioToken) {
      if (prevProps.twilioToken !== this.props.twilioToken) {
        this.props.navigation.navigate('Session');
      }
    }
  }

  render() {
    const { currentUser, navigation } = this.props

    var content: React.ReactElement<any>;
    if (currentUser.role === 'expert') {
      content = (
        <Tabs initialPage={0} style={styles.tabs} onChangeTab={this.onChangeTab}>
          <Tab heading="Pending" tabStyle={{ backgroundColor: '#2E2f39' }} activeTabStyle={{ backgroundColor: '#2E2f39' }} textStyle={{ color: '#fff' }} >
            <Pending navigation={navigation} searchText={this.state.searchText}/>
          </Tab>
          <Tab heading="Completed" tabStyle={{ backgroundColor: '#2E2f39' }} activeTabStyle={{ backgroundColor: '#2E2f39' }} textStyle={{ color: '#fff' }}>
            <Completed searchText={this.state.searchText}/>
          </Tab>
        </Tabs>
      )
    } else {
      content = (<Completed searchText={this.state.searchText}/>)
    }

    return (
      <Container>
        <Notifications/>
        <Invite
          isVisible={this.state.inviteModal}
          callback={this.createSession}
          close={() => this.toggleModal(false)}
          users={currentUser.role === 'expert' ? this.props.groupUsers : this.props.groupExperts}
          sessionId={currentUser._id}
        />
        <Searchbar value={this.state.searchText} onChange={(text) => this.setState({ searchText: text })}/>
        {content}
        <AndroidBackHandler onBackPress={this.handleBackPress} />
      </Container>
    )
  }

  toggleModal(bool?: boolean) {
    this.setState({ inviteModal: (bool ? bool : !this.state.inviteModal) })
  }

  createSession = () => {
    this.toggleModal(true);

    const { authToken, currentUser } = this.props;
    this.props.getToken(authToken, currentUser._id);
  }

  handleBackPress = () => {
    //TODO: logout
    return true;
  }

  onChangeTab = () => {
    this.setState({ searchText: '' })
  }
}

const mapStateToProps = (state: Store) => ({
  currentUser: state.users.current,
  groupUsers: state.users.groupUsers,
  groupExperts: state.users.groupExperts,
  authToken: state.auth.token,
  twilioToken: state.twilio.token,
})

const mapDispatchToProps = {
  getToken,
  tokenReset,
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Sessions);

const styles = StyleSheet.create({
  tabs: {
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {
      height: 0,
      width: 0,
    },
    elevation: 0,
    borderBottomWidth: 0,
  }
})