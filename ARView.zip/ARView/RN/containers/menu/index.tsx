import * as React from 'react'
import { connect } from 'react-redux';
import { NavigationScreenProp, withNavigation } from 'react-navigation'
import { Container, List, ListItem, Icon, Button, Text } from 'native-base'

import { logout } from '../../store/auth/actions'

import { Store } from '../../store';
import LogoutModal from '../../components/modals/logout';

type Props = {
  navigation: NavigationScreenProp<any>,
  logout(): void,
}

class Menu extends React.Component<Props> {
  state = {
    logoutModal: false,
  }

  render() {
    return (
        <Container>
          <LogoutModal
            isVisible={this.state.logoutModal}
            callback={() => this.toggleLogoutModal}
            close={() => this.toggleLogoutModal}
            />
          {/* <List>
            <ListItem>

            </ListItem>
          </List> */}
          <Button onPress={this.logout} style={{ backgroundColor: '#7C91EC', alignSelf: 'center', marginTop: 15 }} >
            <Text style={{ fontSize: 16 }}>Logout</Text>
          </Button>
        </Container>
    )
  }

  logout = () => {
    this.setState({ logoutModal: true })
    // this.props.logout();
    // this.props.navigation.navigate('Auth');
  }

  toggleLogoutModal = (bool?: boolean) => {
    this.setState({ logoutModal: bool ? bool : !this.state.logoutModal })
  }
}

const mapStateToProps = (state: Store) => ({
  
})

const mapDispatchToProps = {
  logout,
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Menu)

type MenuButtonProps = { navigation: NavigationScreenProp<any> }
const _MenuButton = (props: MenuButtonProps) => (
  <Icon 
    name='menu' 
    type='MaterialCommunityIcons' 
    style={{paddingRight: 15, color: '#fff'}} 
    onPress={() => props.navigation.openDrawer()}
  />
)

const MenuButton = withNavigation(_MenuButton);

export { MenuButton }
