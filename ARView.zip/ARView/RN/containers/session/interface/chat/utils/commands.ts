import { Cords } from "../../../viewport/video/types";

const Commands = {
    send: (name: string): void => {
        const command = `2${name}`;
    },

    getCommand: (name: string, cords: Cords) => {
        const command = `2${name} (${cords.x}, ${cords.y})`
        return command;
    }
}

export default Commands;