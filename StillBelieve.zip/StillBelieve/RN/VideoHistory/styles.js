import {
  StyleSheet,
  Dimensions
} from 'react-native';
import { getCorrectFontSizeForScreen } from '@helper/multiResolution'
import * as CLR from '@helper/colors'
var { height, width } = Dimensions.get('window');
import * as CONSTS from '@helper/consts'


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CLR.APP_BLUE,
  },
  headerTitle: {
    color: '#fff',
    fontSize: getCorrectFontSizeForScreen(18),
    alignSelf: 'center',
    fontFamily: CONSTS.REGULAR_FONT,
  },
  bgImageStyle: {
    width: width,
    height: height
  },
  upperContainer: {
    marginVertical: 40,
    alignItems: 'center',
    justifyContent: 'center'
  },
  lowerContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
  },
  menuItemContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 1,
    backgroundColor: '#0a5a99',
    padding: 5
  },
  upperMenuTitle: {
    color: '#fff',
    fontSize: getCorrectFontSizeForScreen(15),
    alignSelf: 'center',
    fontFamily: CONSTS.REGULAR_FONT,
  },
  lowerMenuTitle: {
    color: '#a5b9d0',
    fontSize: getCorrectFontSizeForScreen(13),
    alignSelf: 'center',
    textAlign: 'center',
   fontFamily: CONSTS.REGULAR_FONT,
  },
  inputBox: {
    marginHorizontal: 20,
    marginTop: 20,
    padding: 10,
    paddingLeft: 20,
    backgroundColor: CLR.INPUT_BG,
    alignSelf: 'stretch',
    borderRadius: 20,
    color: CLR.INPUT_TEXT,
    fontSize: getCorrectFontSizeForScreen(13),
    fontFamily: CONSTS.REGULAR_FONT,
  },
  topImageStyle: {
    width: width,
    height: 270,
    alignItems: 'center'
  },
  topHeader: {
    textAlign: 'center',
    backgroundColor: 'transparent',
    fontSize: getCorrectFontSizeForScreen(21),
    color: 'white',
    fontFamily: CONSTS.REGULAR_FONT,
  },
  smallHeader: {
    marginTop: 10,
    textAlign: 'center',
    backgroundColor: 'transparent',
    fontSize: getCorrectFontSizeForScreen(11),
    color: CLR.SMALL_HEADER_TEXT,
    fontFamily: CONSTS.REGULAR_FONT,
  },
  forgotStyle: {
    margin: 10,
    textAlign: 'center',
    color: CLR.FORGOT_COLOR,
    fontFamily: CONSTS.REGULAR_FONT,
  },
  dontHave: {
    textAlign: 'center',
    color: CLR.FORGOT_COLOR,
    fontFamily: CONSTS.REGULAR_FONT,
  },
  signupNow: {
    textAlign: 'center',
    color: CLR.APP_BLUE,
    fontFamily: CONSTS.REGULAR_FONT,
  },signupText: {
    color:'white',
   fontFamily: CONSTS.REGULAR_FONT,
  },
  listMainContainer:{
    flex: 1,
    backgroundColor: '#FFF',
    alignSelf: 'stretch'
  },
  itemContainer:{
    zIndex:2000,
    margin:10,
    backgroundColor:'#C0C0C0',
    marginBottom:2
  },
  actionButtonContainer:{
    flex:1,
    backgroundColor:CLR.APP_BLUE,
    color:'white',
    flexDirection:'row',
    padding:10,
    alignItems:'center',
    justifyContent:'center'
  },
  actionButtonText:{
    color:'#a5b9d0',
    fontSize: getCorrectFontSizeForScreen(9),
   fontFamily: CONSTS.REGULAR_FONT,
    padding:2
  },errorText:{
    marginTop:-50,
    fontSize: getCorrectFontSizeForScreen(14),
    fontFamily: CONSTS.REGULAR_FONT,
    padding:2,
    textAlign:'center'
  }
  ,videoTitle:{
    fontSize:getCorrectFontSizeForScreen(16),
    color:'white',
    fontFamily: CONSTS.REGULAR_FONT,
  },
  videoTime:{
    fontSize:getCorrectFontSizeForScreen(10),
    color:'white',
    fontFamily: CONSTS.REGULAR_FONT,
    paddingRight:20
  }

});
export default styles;
