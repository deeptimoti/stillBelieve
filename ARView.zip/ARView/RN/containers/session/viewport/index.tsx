import * as React from 'react'
import { Container } from 'native-base';

import Video from './video';
import Canvas from './canvas';

export default class Viewport extends React.Component {
  render() {
    return (
      <Container style={{position: 'absolute', width: '100%', height: '100%'}}>
          {/* <Canvas /> */}
          <Video />
      </Container>
    )
  }
}
