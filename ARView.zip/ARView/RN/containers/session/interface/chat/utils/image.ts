import moment from 'moment'

export const Image = {
    send: () => {
        var binary = this.fixBinary(atob(image));
        var blob = new Blob([binary], { type: 'image/png' });

        const data = new FormData();
        data.append('file', blob, filename);
    },

    setFilename: (type: ImageTypes, identity: string, ) => {
        const filename = `${type}__${identity}__${moment().toISOString()}.png`;
    },

    fixBinary: (bin: any) => {
        var length = bin.length;
        var buf = new ArrayBuffer(length);
        var arr = new Uint8Array(buf);
        for (var i = 0; i < length; i++) {
          arr[i] = bin.charCodeAt(i);
        }
        return buf;
      }
}

type ImageTypes = 'stamp' | 'camera';